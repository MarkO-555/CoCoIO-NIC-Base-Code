/*************************************************************************/
/* echoudpc.c                                                            */
/* David C. Wise, 2004, 2011                                             */
/* Email: dwise1@aol.com                                                 */
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* Server Stress Test Driver Echo Client Example                         */
/* Sends a message repeatedly to the server in order to test the         */
/*      server's ability to handle the load.                             */
/* Multiple instances of this client are used in the stress test.        */
/* The message is predetermined and arbitrarily set to the               */
/*      70-character-long typing exercise:  "Now is the time for         */
/*          all good men to come to the aid of their country."           */
/*                                                                       */
/* Usage: echoudpc <Server IP> [<Echo Port>]                             */
/*      Server IP must be in dotted-decimal format                       */
/*              does not do DNS                                          */
/*      Echo Port is optional; will default to 7 if not included         */
/*      After each message to the server, the program will test          */
/*          the keyboard for input.  Pressing the escape key (Esc)       */
/*          or the 'q' will cause the program to terminate.              */
/*                                                                       */
/*************************************************************************/
/* Based on and modified from code examples from                         */
/*      "The Pocket Guide to TCP/IP Sockets: C Version"                  */
/*                 by Michael J. Donahoo and Kenneth L. Calvert:         */
/*         UDPEchoClient.c                                               */
/*         DieWithError.c                                                */
/*                                                                       */
/* The original UNIX source code is freely available from their web site */
/*      at                                                               */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/*      and the Winsock version of the code at                           */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/winsock.html  */
/*                                                                       */
/* Please read the authors' disclaimer on their web site at              */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/* In particular note that "the authors and the Publisher DISCLAIM ALL   */
/*      EXPRESS AND IMPLIED WARRANTIES, including warranties of          */
/*      merchantability and fitness for any particular purpose.          */
/* Your use or reliance upon any sample code or other information in     */
/*      [their] book will be at your own risk.                           */
/* No one should use any sample code (or illustrations) from [their]     */
/*      book in any software application without first obtaining         */
/*      competent legal advice."                                         */
/*                                                                       */
/*************************************************************************/
/* This program will compile under Windows or UNIX/Linux depending on    */
/*      the setting of the WINSOCK_EXAMPLE define                        */
/* The Winsock version will require the Winsock library to be linked in  */
/*      (exact method and library name are compiler-dependent)           */ 
/*************************************************************************/

/* #define for Windows; #undef for UNIX/Linux */
#define WINSOCK_EXAMPLE

#include <stdlib.h>     /* for exit() */
#include <stdio.h>      /* for printf(), fprintf() */
#include <string.h>     /* for string functions  */
#ifdef WINSOCK_EXAMPLE
#include <conio.h>       /* for kbhit, getch  */
#include <winsock2.h>    /* for socket(),... */
#else
#include <unistd.h>     /* for close() */
#include <sys/socket.h> /* for socket(),... */
#include <netinet/in.h> /* for socket(),... */
#include <arpa/inet.h>  /* for inet_addr() */
#endif    


#define ECHOMAX     255  /* Longest string to echo */
#define ECHO_PORT   7    /* Default standard port number for echo   */

void RunStressTest(int sock, struct sockaddr_in echoServAddr);
void ReportError(char *errorMessage);   /* Error handling function (no exit) */
void DieWithError(char *errorMessage);  /* Fatal Error handling function     */

/********************************************************************/
/* main -- like opinions, every program has one.                    */
/********************************************************************/
int main(int argc, char *argv[])
{
    int sock;                        /* Socket descriptor */
    struct sockaddr_in echoServAddr; /* Echo server address */
    unsigned short echoServPort;     /* Echo server port */
    char *servIP;                    /* IP address of server */
    char *echoString;                /* String to send to echo server */
    int echoStringLen;               /* Length of string to echo */
#ifdef WINSOCK_EXAMPLE
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */ 
#endif    

    /* First process the command-line arguments. */
    if ((argc < 2) || (argc > 3))    /* Test for correct number of arguments */
    {
        fprintf(stderr,"Usage: %s <Server IP> [<Echo Port>]\n", argv[0]);
        exit(1);
    }

    servIP = argv[1];           /* first arg: server IP address (dotted quad)*/

    if (argc == 3)
        echoServPort = atoi(argv[2]);  /* Use given port, if any */
    else
        echoServPort = ECHO_PORT;  /* otherwise, use the default port number */

#ifdef WINSOCK_EXAMPLE
    /* Winsock DLL and library initialization  */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }
#endif    

    /* Create a best-effort datagram socket using UDP */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");

    /* Construct the server address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));    /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                 /* Internet address family */
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);  /* Server IP address */
    echoServAddr.sin_port   = htons(echoServPort);     /* Server port */

    // use the socket to exercise the server
    RunStressTest(sock, echoServAddr);


#ifdef WINSOCK_EXAMPLE
    /* Winsock requires a special function for sockets */
    closesocket(sock);    /* Close client socket */

    WSACleanup();  /* Cleanup Winsock */
#else
    close(sock);    /* Close client socket */
#endif    

    return 0;
}


/********************************************************************/
/* RunStressTest                                                    */
/*    Repeatedly calls the server, exercising it.                   */
/*    Keeps track of whether it receives a response within 2 sec.   */
/*    Exits when the user enters either the escape key or the 'q'.  */
/********************************************************************/
void RunStressTest(int sock, struct sockaddr_in echoServAddr)
{    
    fd_set sockSet;                  /* Set of socket descriptors for select() */
    struct timeval selTimeout;       /* Timeout for select() */
    int iResult;
    struct sockaddr_in fromAddr;     /* Source address of echo */
    unsigned int fromSize;           /* In-out of address size for recvfrom() */
    char *echoString = "Now is the time for all good men to come to the aid of their country.";
                                    /* String to send to echo server */
    int echoStringLen;               /* Length of string to echo */
    char echoBuffer[ECHOMAX];        /* Buffer for echo string */
    int respStringLen;               /* Length of response string */
    char  ch;
    int  droppedMessages = 0;
    int  errors = 0;

    echoStringLen = strlen(echoString) + 1;

    // loop infinitely until keyboard enter breaks us out.
    for (;;)
    {
        /* Send the string, including the null terminator, to the server */
        if (sendto(sock, echoString, echoStringLen, 0, (struct sockaddr *)
                   &echoServAddr, sizeof(echoServAddr)) != echoStringLen)
            DieWithError("sendto() sent a different number of bytes than expected");
      
        /* Receive (recvfrom()) the server's response.            */
        /* Use select() to time out of a no-response situation    */

        /* Zero socket descriptor vector and set for the sockets to test */
        /* This must be reset every time select() is called              */
        FD_ZERO(&sockSet);
        FD_SET(sock, &sockSet);
#ifndef WINSOCK_EXAMPLE
        /* on UNIX/Linux systems, use select() to detect keyboard input */
        FD_SET(0, &sockSet);  // stdin; only works on UNIX/Linux
#endif

        /* Timeout specification */
        /* This must be reset every time select() is called */
        selTimeout.tv_sec = 2;       /* timeout (secs.) */
        selTimeout.tv_usec = 0;            /* 0 microseconds */

        iResult = select(0, &sockSet, NULL, NULL, &selTimeout);
        
        if (iResult == -1)
        {
            /* an error occurred; process it (eg, display error message) */
            ReportError("select() failed");
            errors++;
        }
        else if (!iResult)  // no response within two seconds 
        {
            printf("No Response\n");
            droppedMessages++;
        }
        else // got a response from either the socket or the keyboard
        {
            if (FD_ISSET(sock, &sockSet) )
            {
                fromSize = sizeof(fromAddr);
                if ((respStringLen = recvfrom(sock, echoBuffer, ECHOMAX, 0, (struct sockaddr *) &fromAddr, 
                             &fromSize)) != echoStringLen)
                    DieWithError("recvfrom() failed");

                /* Verify that the response came from the server and not from somewhere else */
                if (echoServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
                {
                    fprintf(stderr,"Error: received a packet from unknown source.\n");
                    exit(1);
                }

                /* Process the received message */
                if (echoBuffer[respStringLen-1])  /* Do not printf unless it is terminated */
                {
                    printf("Received an unterminated string\n");
                    errors++;
                }
                else
                    printf("Received: %s\n", echoBuffer);    /* Print the echoed arg */
            }
#ifndef WINSOCK_EXAMPLE
            else if (FD_ISSET(0, &sockSet) ) // stdin
            {
                ch = getchar();
                if (ch == 'q' || ch == 27)
                    break;
            }
#endif        
        }
            
        /* test for exit key, else use select for a timeout */

#ifdef WINSOCK_EXAMPLE
        if (kbhit())
        {
            ch = tolower(getch());
            if (ch == 'q' || ch == 27)
                break;
        }
#endif        
    }    

    /* report the counts */
    printf("%d Dropped Messages, %d errors.\n", droppedMessages, errors);
}



/********************************************************/
/* DieWithError                                         */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void DieWithError(char *errorMessage)
{
    ReportError(errorMessage);
    exit(1);
}

/**************************************************************************/
/* ReportError                                                            */
/*    Displays a message that reports the error                           */
/*    Encapsulates the difference between UNIX and Winsock error handling */
/* Winsock Note:                                                          */
/*    WSAGetLastError() only returns the error code number without        */
/*    explaining what it means.  A list of the Winsock error codes        */
/*    is available from various sources, including Microsoft's            */
/*    on-line developer's network library at                              */
/*  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winsock/winsock/windows_sockets_error_codes_2.asp */
/**************************************************************************/
void ReportError(char *errorMessage)
{
#ifdef WINSOCK_EXAMPLE
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
#else
    perror(errorMessage);
#endif    
}

/* End of File */
