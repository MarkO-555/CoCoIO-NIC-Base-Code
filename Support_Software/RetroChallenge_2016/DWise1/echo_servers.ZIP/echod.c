/*************************************************************************/
/* echod.c                                                               */
/* David C. Wise, 2004, 2011                                             */
/* Email: dwise1@aol.com                                                 */
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* Multi-Client TCP Echo Server Example Using Select                     */
/* Establishes and maintains TCP connections with up to 10 clients       */
/* With each client, receives and echos a series of messages,            */
/*      one at a time.                                                   */
/* Services any number of clients, up to 10 at a time; never exits       */
/*                                                                       */
/* Usage: echod [<Server Port>]                                          */
/*      Server Port is optional; will default to 7 if not included       */
/* NOTE: for security reasons, on many systems (eg, Linux) only a        */
/*      privileged program or user is allowed to bind to a well-known    */
/*      port.  Therefore, it will probably be necessary for you pick a   */
/*      port from outside the well-known range; ie from 1024 to 65536.   */
/*                                                                       */
/* Basic Sequence of Operations:                                         */
/*      1. Create a socket.                                              */
/*      2. Bind the socket to a specific port with the bind() function   */
/*              and make it a listening socket.                          */
/*      3. Periodically set up and call select to determine which        */
/*              sockets have received data and hence will not block.     */
/*      4. For the listening socket, accept the connection, which        */
/*              creates a client socket and starts the actual session    */
/*              for that client.  There can be multiple clients and      */
/*              hence multiple sessions.                                 */
/*      5. For each client who sent a request, receive and service that  */
/*              request.                                                 */
/*      6. Close the connection when informed of the client's            */
/*              shutdown action, close that client socket, and remove    */
/*              that client.                                             */
/*      7. Perform other activities, then periodically return to Step 3  */
/*              to call select again.                                    */
/*************************************************************************/
/* Based on and modified from code examples from                         */
/*      "The Pocket Guide to TCP/IP Sockets: C Version"                  */
/*                 by Michael J. Donahoo and Kenneth L. Calvert:         */
/*         TCPEchoServer.c                                               */
/*         HandleTCPClient.c                                             */
/*         DieWithError.c                                                */
/*         TCPEchoServer.h                                               */
/*                                                                       */
/* The original UNIX source code is freely available from their web site */
/*      at                                                               */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/*      and the Winsock version of the code at                           */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/winsock.html  */
/*                                                                       */
/* Please read the authors' disclaimer on their web site at              */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/* In particular note that "the authors and the Publisher DISCLAIM ALL   */
/*      EXPRESS AND IMPLIED WARRANTIES, including warranties of          */
/*      merchantability and fitness for any particular purpose.          */
/* Your use or reliance upon any sample code or other information in     */
/*      [their] book will be at your own risk.                           */
/* No one should use any sample code (or illustrations) from [their]     */
/*      book in any software application without first obtaining         */
/*      competent legal advice."                                         */
/*                                                                       */
/*************************************************************************/
/* This program will compile under Windows or UNIX/Linux depending on    */
/*      the setting of the WINSOCK_EXAMPLE define                        */
/* The Winsock version will require the Winsock library to be linked in  */
/*      (exact method and library name are compiler-dependent)           */ 
/*************************************************************************/

/* #define for Windows; #undef for UNIX/Linux */
#define WINSOCK_EXAMPLE

#include <stdlib.h>     /* for exit() */
#include <ctype.h>     /* for memset() */
#include <stdio.h>      /* for printf(), fprintf() */
#include <conio.h>     /* for memset() */
#include <string.h>     /* for memset() */
#ifdef WINSOCK_EXAMPLE
#include <winsock2.h>    /* for socket(),... */
#else
#include <unistd.h>     /* for close() */
#include <sys/socket.h> /* for socket(),... */
#include <netinet/in.h> /* for socket(),... */
#include <arpa/inet.h>  /* for inet_addr() */
#endif    

#define MAXSOCKS    10
int socks[MAXSOCKS]; // array of current sockets
int num_socks = 0;

#define MAXPENDING  5    /* Maximum outstanding connection requests */
#define ECHO_PORT   7    /* Default standard port number for echo   */
#define RCVBUFSIZE 32   /* Size of receive buffer */

void ProcessCLArgs(int argc,char *argv[],unsigned short *port);
void ProcessSocket(unsigned short port);
void RunSessions(int servSock);
void ReportError(char *errorMessage);   /* Error handling function (no exit) */
void DieWithError(char *errorMessage);  /* Fatal Error handling function     */
void CloseWithError(int clntSocket, char *errorMessage); /* close socket upon error condition */
void HandleTCPClient(int clntSocket, struct sockaddr_in *clntAddr);   /* TCP client handling function */
int addClient(int sock);
void removeClient(int sock);

/********************************************************************/
/* main -- like opinions, every program has one.                    */
/********************************************************************/
int main(int argc,char *argv[])
{
    unsigned short echoServPort;     /* Server port */

    ProcessCLArgs(argc,argv, &echoServPort);
    ProcessSocket(echoServPort);
    
    return 0;
}


/********************************************************************/
/* ProcessCLArgs                                                    */
/*    Check the command line arguments for validity.                */
/*    Read in the server port number.                               */
/********************************************************************/
void ProcessCLArgs(int argc,char *argv[],unsigned short *port)
{

    /* First process the command-line arguments. */
    /* NOTE: for security reasons, on many systems only a privileged 
        program or user is allowed to bind to a well-known port.  
        Therefore, it will probably be necessary for you pick a high-numbered one.  */
    
    /* Test for correct number of arguments and read in parameter (if any) */
    if (argc > 2)    
    {
        fprintf(stderr, "Usage:  %s [<Server Port>]\n", argv[0]);
        exit(1);
    } 
    else if (argc == 2)
        *port = atoi(argv[1]);  /* first arg:  Local port */
    else
        *port = ECHO_PORT;      /* set to default port, 7 */
}


/********************************************************************/
/* ProcessSocket                                                    */
/*    Initialize Winsock.                                           */
/*    Create the listening socket and pass it to RunSessions        */
/********************************************************************/
void ProcessSocket(unsigned short port)
{
    int servSock;                    /* Socket descriptor for server */
    struct sockaddr_in echoServAddr; /* Local address */
#ifdef WINSOCK_EXAMPLE
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */ 
#endif    


#ifdef WINSOCK_EXAMPLE
    /* Winsock DLL and library initialization  */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }
#endif    

/* 1. Create a socket.  */
    /* Create socket for incoming connections */
    if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");

/* 2. Bind the socket to a specific port with the bind() function.  */
    /* First we construct local address structure containing that port we will bind to*/
    memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    echoServAddr.sin_port = htons(echoServPort);      /* Local port */

    /* Then we perform the actual binding operation */
    if (bind(servSock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0)
        DieWithError("bind() failed");

/* 3. Listen on that port for a client trying to connect to it.  */
    /* Mark the socket so it will listen for incoming connections */
    if (listen(servSock, MAXPENDING) < 0)
        DieWithError("listen() failed");

    RunSessions(servSock);
}

/********************************************************************/
/* RunSessions                                                      */
/*    Conducts the echo session.                                    */
/*    Tests the client sockets for incoming data and the listening  */
/*       socket for new connections and services them accordingly.  */
/*    Exits when a ESC or 'q' key is pressed.                       */
/********************************************************************/
void RunSessions(int servSock)
{
    int clntSock;                    /* Socket descriptor for client */
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned int clntLen;            /* Length of client address data structure */
    fd_set readSet;                  /* Set of socket descriptors for select() */
    long timeout = 0;                    /* Timeout value given on command-line */
    struct timeval selTimeout;       /* Timeout for select() */
    int running = 1;                 /* 1 if server should be running; 0 otherwise */
    int port;                        /* Looping variable for ports */
    int hi_port;
    int result;
    char ch;
    int closed[MAXSOCKS]; // array of current sockets
    int num_closed;

    /* Set the size of the client-address parameter */
    clntLen = sizeof(echoClntAddr);

    /* Wait for and handle one client at a time                       */
    /* Exit the loop by pressing either of two keys: "Q" or Esc.      */
    /* A production-quality server would need a more elegant way to   */
    /*    be stopped.                                                 */
    while (running) /* Run forever */
    {
        /* Zero socket descriptor vector and set for server sockets */
        /* This must be reset every time select() is called */
        FD_ZERO(&readSet);
        hi_port = 0;            // required by UNIX select, not by Winsock's
        FD_SET(servSock, &readSet);
        for (port = 0; port < num_socks; port++)
        {
            FD_SET(socks[port], &readSet);
            if (socks[port] > hi_port)
                hi_port = socks[port];

        }            

        /* Timeout specification */
        /* This must be reset every time select() is called */
        selTimeout.tv_sec = timeout;       /* timeout (secs.) */
        selTimeout.tv_usec = 500;            /* 0 microseconds */

        /* Suspend program until descriptor is ready or timeout */
        /* The first parameter to select() is ignored in Winsock */
        if (( result = select(hi_port+1, &readSet, NULL, NULL, &selTimeout)) == -1)
            ReportError("select() failed");
        else if (result > 0)
        {
            // first test the client sockets
            for (port = 0; port < num_socks; port++)
            {
                if (FD_ISSET(socks[port], &readSet))
                {
                    printf("Request on port %d (cmd-line position):  ", port);
                    getpeername(clntSock, (struct sockaddr *) &echoClntAddr, &clntLen);
                    /* Actual servicing of the client moved off to a separate function      */
                    /* In a multithreaded server, a new worker thread would be created here */
                    /* Will perform the calls to send(), recv(), shutdown, and close */
                    HandleTCPClient(socks[port], &echoClntAddr);
                }
            }  /* for */
            
            // then test the listening socket
            if (FD_ISSET(servSock, &readSet))
            {
                /* Wait for a client to connect                                  */
                /* NOTE:                                                         */ 
                /*   This operation will block until a client connects, causing  */
                /*       the server to "freeze" during that wait.                */
                /*   While that makes no difference in this simple application,  */
                /*       you would want to work around this in a production app. */
                if ((clntSock = accept(servSock, (struct sockaddr *) &echoClntAddr, 
                                        &clntLen)) < 0)
                    DieWithError("accept() failed");

                /* clntSock is connected to a client! */
                /* Report the connection to stdout    */
                printf("Handling client %s\n", inet_ntoa(echoClntAddr.sin_addr));
                
                if (addClient(clntSock) == -1)
                {
                    printf("Too many clients\n");
                }
                else
                    printf("%d clients currently connected\n",num_socks-1);
            }
            
        }  // end if (result > 0)

        // check UI
        while (kbhit())
        {
            ch = getch();
            if ( (tolower(ch) == 'q') || (ch == 27) )
            {
                running = 0;
                break;
            }
        }
        
    }  /* end for(;;) */

}


/********************************************************************/
/* addClient                                                        */
/*    Adds a new client's socket to the client list.                */
/********************************************************************/
int addClient(int sock)
{
    if (num_socks >= MAXSOCKS)
        return -1;
        
    socks[num_socks++] = sock;
    return 0;        
}

/********************************************************************/
/* removeClient                                                     */
/*    Removes an existing client from the client list.              */
/*    Protected in a critical section.                              */
/********************************************************************/
void removeClient(int sock)
{
    int i;
    
    // find index of entry containing socket
    // this for-loop intentionally has no body
    for (i=0; i<num_socks && socks[i] != sock; i++);
    
    if (i<num_socks)
    {
        for ( ; i<num_socks; i++)
            socks[i] = socks[i+1];
            
        num_socks--;            
    }
}



/********************************************************************/
/* HandleTCPClient                                                  */
/*    Function for servicing the client                             */
/*    Spun off as a separate function in order to simplify the main */
/*        function and to separate the echo protocol from the basic */
/*        sockets operations as much as possible.                   */
/********************************************************************/
void HandleTCPClient(int clntSocket, struct sockaddr_in *clntAddr)
{
    char echoBuffer[RCVBUFSIZE];        /* Buffer for echo string */
    int  recvMsgSize;                   /* Size of received message */
    int  send_failed;                   /* flag that the send() call failed */

    /* Send received string and receive again until end of transmission */
        /* Receive message from client */
        /* NOTE:                        */ 
        /*   This operation will block until it receives a message from the  */
        /*       client, causing  the server to "freeze" during that wait.   */
        /*   While that makes no difference in this simple application,      */
        /*       you would want to work around this in a production app.     */
        recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0);
        printf("Received %d bytes\n",recvMsgSize);
        if (recvMsgSize < 0)
            CloseWithError(clntSocket, "recv() failed");
        else if (!recvMsgSize)  /* zero means the client is disconnecting */
        {
            /* Report the client's shutdown to stdout    */
            printf("Client %s shutting down\n", inet_ntoa(clntAddr->sin_addr));
            /* Close the connection when informed of the client's shutdown action. */
            shutdown(clntSocket,1);    /* signal that we're done sending  */

            /* Close the client socket.  */
#ifdef WINSOCK_EXAMPLE
            /* Winsock requires a special function for sockets */
            closesocket(clntSocket);    /* Close client socket */
#else
            close(clntSocket);    /* Close client socket */
#endif    
            removeClient(clntSocket);
            
            /* Report the client's shutdown to stdout    */
            printf("Closing client %s\n", inet_ntoa(clntAddr->sin_addr));
            printf("%d clients currently connected\n",num_socks-1);
        }
        /* Only if we actually received a message do we echo it back */
        if (recvMsgSize > 0)
        {

            /* Echo message back to client */
            /* NOTE:  blocks until the message is sent  */
            /*    Not normally a problem.               */
            if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
            {
                CloseWithError(clntSocket, "send() failed");
                send_failed = 1;  /* break out of while loop and close socket */
            }
            else
                send_failed = 0;
        }

}

/********************************************************/
/* DieWithError                                         */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void DieWithError(char *errorMessage)
{
    ReportError(errorMessage);
    exit(1);
}

/********************************************************/
/* CloseWithError                                       */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void CloseWithError(int clntSocket, char *errorMessage)
{
    ReportError(errorMessage);
#ifdef WINSOCK_EXAMPLE
    /* Winsock requires a special function for sockets */
    closesocket(clntSocket);    /* Close client socket */
#else
    close(clntSocket);    /* Close client socket */
#endif    
    removeClient(clntSocket);
}

/**************************************************************************/
/* ReportError                                                            */
/*    Displays a message that reports the error                           */
/*    Encapsulates the difference between UNIX and Winsock error handling */
/* Winsock Note:                                                          */
/*    WSAGetLastError() only returns the error code number without        */
/*    explaining what it means.  A list of the Winsock error codes        */
/*    is available from various sources, including Microsoft's            */
/*    on-line developer's network library at                              */
/*  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winsock/winsock/windows_sockets_error_codes_2.asp */
/**************************************************************************/
void ReportError(char *errorMessage)
{
#ifdef WINSOCK_EXAMPLE
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
#else
    perror(errorMessage);
#endif    
}

/* End of File */

#if 0
// read & resolve args

// create socket & connect
sock = socket(
addr_in
bind(sock,
listen(sock
socks[num_socks++] = sock;
hi_sock = sock;

// enter select loop
while(running)
{
// set up fd_set
FD_ZERO(read_set);
for (i=0; i < num_socks; i++)
{
set socks[i]
set hi_sock
}
// set timeout
n_sock = select(hi_sock+1,read_set,NULL,NULL,timeout);
if (n_sock)
{//process reads
}
// process UI
// could include quit cmd
}

int process_read(SOCKET sock)
{
// read socket
n = recv(sock,);
// interpret n
if (n > 0)
{
OutputMsg(buf);
}
else if(n ==-1)
{// process error
// function call which centralizes reporting, logging, terminating
}
else  // is 0, process shutdown
{
shutdown(sock,1);
}
}

OutputMsg(buf) will be a hook for the app to handle the output.
#endif
