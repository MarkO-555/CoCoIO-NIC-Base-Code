Multi-Client Echo Servers

This is an extension of my echo client/server sample apps.
I have rewritten the TCP echo server to handle multiple clients using 
three different techniques: select, nonblocking sockets, and multithreading.
Both servers work with the same echo client as before, tcp_client.c, 
but which, for this package, I have renamed as echoc, for "echo client"
(the DOS command, echo, already exists, so I tacked on the "c" to
get around that).

echod, uses select() to handle the multiple clients 
as well as the accept() calls.  Basically, all the sockets -- ie,
the listening socket as well as the sockets for all the clients
currently connected -- are tested with a call to select() and then
each existing socket is tested for having something to be read, 
whereupon that socket is processed (accept() call for the listening
socket and recv() call for the client sockets).  At the end of 
the loop that repeatedly calls select() is a test for a keyboard
key having been pressed; if that key is either "Q" or Esc, then
the server program terminates.

echonbd, uses nonblocking sockets to handle the multiple clients 
as well as the accept() calls.  After each socket is created, it
is converted into a nonblocking socket.  Then the open sockets
are called repeatedly in sequence and if the call resulted in an
error, then that error is checked for EWOULDBLOCK, in which case
the socket is ignored and the next socket gets read.  At the end of 
the loop that repeatedly calls select() is a test for a keyboard
key having been pressed; if that key is either "Q" or Esc, then
the server program terminates.

echoMTd, uses multithreading to do much the same.  In
this server, the main thread creates an Accept Thread that calls
accept() and sits there blocked until a client connects.  When a
client connects, the Accept Thread creates a client thread and
then calls accept() again and sits there blocked until another
client connects.  Each client that connects has its own individual
client thread dedicated to it and to it alone.  Each client thread
sits there blocked on recv() until it receives a message from the 
client, which it processes and then returns to sitting blocked on
recv().  When the client does a shutdown, the client thread processes
it, removes the client from the client array, and terminates the thread.
Meanwhile, back in the main() function, the main thread is looping 
on testing for a keyboard key having been pressed; the server terminates
if a "Q" or Esc has been pressed.

echoudpd, the UDP server, is the same as in the basic echo apps.
It is included here to illustrate that a basic UDP server can service
multiple clients, since it does not maintain a connection but rather
handles each datagram separately.  

echoc, the TCP echo client, is the same as in the basic echo apps, but
with two changes:
1. It requests the echo string from the user and, instead of exiting 
immediately after sending one echo request, it loops back and asks for
another echo string to send.  The user exits the program by entering
a null message (just hit ENTER without typing anything in).
2. An option, -r, was added to repeatedly send a predefined string
repeatedly without delay.  This enables the user to conduct a stress 
test of the server, especially by running multiple clients simultaneously.
While using the -r option, exit the client by pressing either the "Q"
or the Esc key.

echoudpc, the UDP echo client, is not the same as in the basic echo apps.
In order to stress test the UDP server, echoudpc only runs in the "-r"
mode, repeatedly sending a predefined string without delay.  To exit
the client, press either the "Q" or the Esc key.


To compile the programs with MinGW gcc that comes with Dev-C++, use
the following command line invocations or their Dev-C++ equivalents:

gcc -o echoc echoc.c -lws2_32
gcc -o echod echod.c -lws2_32
gcc -o echonbd echonbd.c -lws2_32
gcc -o echoMTd echoMTd.c -lws2_32
gcc -o echoudpc echoudpc.c -lws2_32
gcc -o echoudpd echoudpc.d -lws2_32

I've included the .exe executables created on my Windows machine, but for
basic common-sense security reasons, as well as for your own edification,
you should build your own executables from the source.


Share and enjoy!
