/*************************************************************************/
/* echomtd.c                                                             */
/* David C. Wise, 2004, 2011                                             */
/* Email: dwise1@aol.com                                                 */
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* Multi-Client TCP Echo Server Example with Multithreading              */
/* Establishes and maintains TCP connections with up to 10 clients       */
/* With each client, receives and echos a series of messages,            */
/*      one at a time.                                                   */
/* Services any number of clients, up to 10 at a time; never exits       */
/*                                                                       */
/* Usage: echomtd [<Server Port>]                                        */
/*      Server Port is optional; will default to 7 if not included       */
/* NOTE: for security reasons, on many systems (eg, Linux) only a        */
/*      privileged program or user is allowed to bind to a well-known    */
/*      port.  Therefore, it will probably be necessary for you pick a   */
/*      port from outside the well-known range; ie from 1024 to 65536.   */
/*                                                                       */
/* Basic Sequence of Operations:                                         */
/*      1. Create a listening socket.                                    */
/*      2. Start the AcceptThread which will accept a new connection     */
/*          and create a ClientThread for it.                            */
/*      3. The ClientThread waits for a string from the client.          */
/*          Although that blocks it, all of other threads are still      */
/*          able to execute independently.  Up to 10 ClientThreads can   */
/*          exist and be running at a single time; that limit of 10      */
/*          can be changed.                                              */
/*      4. When a ClientThread receives (recv()) the client's message,   */
/*          it sends (send()) the response (ie, echos it back).          */
/*          Then it returns to receiving the client's next message,      */
/*          causes it to block.                                          */
/*      5. When a client chooses to shutdown the connection, its         */
/*          ClientThread detects that and performs the shutdown on       */
/*          server side.  Then it terminates itself.                     */
/*      6. Wait for the next message from a client                       */
/*             (could be the same client or a different one).            */
/*                                                                       */
/* CAVEAT:                                                               */
/*  This program contains just a rudimentary multithreading              */
/*      implementation and does not even remotely qualify as any kind    */
/*      of "best practices" example.  You may study this example as a    */
/*      starting point, but cannot rely on it being robust.              */
/*************************************************************************/
/* Based on and modified from code examples from                         */
/*      "The Pocket Guide to TCP/IP Sockets: C Version"                  */
/*                 by Michael J. Donahoo and Kenneth L. Calvert:         */
/*         TCPEchoServer.c                                               */
/*         HandleTCPClient.c                                             */
/*         DieWithError.c                                                */
/*         TCPEchoServer.h                                               */
/*                                                                       */
/* The original UNIX source code is freely available from their web site */
/*      at                                                               */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/*      and the Winsock version of the code at                           */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/winsock.html  */
/*                                                                       */
/* Please read the authors' disclaimer on their web site at              */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/* In particular note that "the authors and the Publisher DISCLAIM ALL   */
/*      EXPRESS AND IMPLIED WARRANTIES, including warranties of          */
/*      merchantability and fitness for any particular purpose.          */
/* Your use or reliance upon any sample code or other information in     */
/*      [their] book will be at your own risk.                           */
/* No one should use any sample code (or illustrations) from [their]     */
/*      book in any software application without first obtaining         */
/*      competent legal advice."                                         */
/*                                                                       */
/*************************************************************************/
/* This program is only written to compile under Windows.                */
/* The reason for this decision is that I am so much more familiar       */
/*      with multithreading under Windows than under Linux.              */
/* Since this version uses Winsock, the Winsock library must be linked   */
/*      in (exact method and library name are compiler-dependent)        */ 
/*************************************************************************/


#include <stdlib.h>     /* for exit() */
#include <ctype.h>     /* for memset() */
#include <stdio.h>      /* for printf(), fprintf() */
#include <conio.h>     /* for memset() */
#include <string.h>     /* for memset() */
#include <winsock2.h>    /* for socket(),... */
#include <process.h>


#define MAXSOCKS    10  // maximum number of clients; can be changed
SOCKET socks[MAXSOCKS]; // array of current sockets
int num_socks = 0;

#define MAXPENDING  5    /* Maximum outstanding connection requests */
#define ECHO_PORT   7    /* Default standard port number for echo   */
#define RCVBUFSIZE 32    /* Size of receive buffer */
#define RPTBUFSIZE 80    /* Size of report strings  */

struct ClientRec
{
    SOCKET  sock;
    int     ID;
};

CRITICAL_SECTION csReports;
CRITICAL_SECTION csClientList;


void ProcessCLArgs(int argc,char *argv[],unsigned short *port);
void ProcessSocket(unsigned short port);
void RunSessions(SOCKET servSock);
/* Error handling function (no exit) */
void ReportError(char *errorMessage);   
 /* Fatal Error handling function     */
void DieWithError(char *errorMessage); 
/* close socket upon error condition */
void CloseWithError(SOCKET clntSocket, char *errorMessage); 
/* TCP client handling function */
void HandleTCPClient(SOCKET clntSocket, struct sockaddr_in *clntAddr);   
int addClient(SOCKET sock);
void removeClient(SOCKET sock);
void AddReport(char *sRpt);
void GetReport(void);

/* Thread functions */
void AcceptThread(void *x);
void ClientThread(void *x);

/********************************************************************/
/* main -- like opinions, every program has one.                    */
/********************************************************************/
int main(int argc,char *argv[])
{
    int     running = 1;  /* 1 if server should be running; 0 otherwise */
    char    ch;
    unsigned short echoServPort;     /* Server port */

    // initialize the critical section protecting access to printf
    InitializeCriticalSection(&csReports);    
    InitializeCriticalSection(&csClientList);    

    ProcessCLArgs(argc,argv, &echoServPort);
    ProcessSocket(echoServPort);

    while (running)
    {
        Sleep(100);
        while (kbhit())
        {
            ch = getch();
            if ( (tolower(ch) == 'q') || (ch == 27) )
            {
                running = 0;
                break;
            }
        }

        EnterCriticalSection(&csReports);
        GetReport();
        LeaveCriticalSection(&csReports);
    }
    

    /* Clean up Winsock */
    WSACleanup();  
        
    // initialize the critical section protecting access to printf
    DeleteCriticalSection(&csReports);
    DeleteCriticalSection(&csClientList);
    
    return 0;
}


/********************************************************************/
/* ProcessCLArgs                                                    */
/*    Check the command line arguments for validity.                */
/*    Read in the server port number.                               */
/********************************************************************/
void ProcessCLArgs(int argc,char *argv[],unsigned short *port)
{

    /* First process the command-line arguments. */
    /* NOTE: for security reasons, on many systems only a privileged */
    /*      program or user is allowed to bind to a well-known port. */ 
    /*      Therefore, it will probably be necessary for you pick a  */
    /*      high-numbered one.                                       */
    
    /* Test for correct number of arguments     */
    /*    and read in parameter (if any)        */
    if (argc > 2)    
    {
        fprintf(stderr, "Usage:  %s [<Server Port>]\n", argv[0]);
        exit(1);
    } 
    else if (argc == 2)
        *port = atoi(argv[1]);  /* first arg:  Local port */
    else
        *port = ECHO_PORT;      /* set to default port, 7 */
}


/********************************************************************/
/* ProcessSocket                                                    */
/*    Initialize Winsock.                                           */
/*    Create the listening socket and pass it to AcceptThread       */
/********************************************************************/
void ProcessSocket(unsigned short port)
{
    SOCKET servSock;                 /* Socket descriptor for server */
    struct sockaddr_in echoServAddr; /* Local address */
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */ 


    /* Winsock DLL and library initialization  */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }

    /* Create socket for incoming connections */
    if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");

    /* Bind the socket to a specific port with the bind() function.  */
    /* First we construct local address structure containing that    */
    /*      port we will bind to                                     */            
    
    /* Zero out struct, Internet address family, any incoming  */
    /*      interface, local port                              */
    memset(&echoServAddr, 0, sizeof(echoServAddr));   
    echoServAddr.sin_family = AF_INET;                
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    echoServAddr.sin_port = htons(port);      

    /* Then we perform the actual binding operation */
    if (bind(servSock, (struct sockaddr *) &echoServAddr, 
                sizeof(echoServAddr)) < 0)
        DieWithError("bind() failed");

    /* Mark the socket so it will listen for incoming connections */
    if (listen(servSock, MAXPENDING) < 0)
        DieWithError("listen() failed");

    /* Start the AcceptThread  */    
    if (_beginthread(AcceptThread, 0, (void*)&servSock) == -1) 
    {
        fprintf(stderr, "AcceptThread failed to start");
        exit(1);
    }

}

/********************************************************************/
/* addClient                                                        */
/*    Adds a new client's socket to the client list.                */
/*    Protected in a critical section.                              */
/********************************************************************/
int addClient(SOCKET sock)
{
    EnterCriticalSection(&csClientList);
    if (num_socks >= MAXSOCKS)
    {
        LeaveCriticalSection(&csClientList);
        return -1;
    }        
        
    socks[num_socks++] = sock;
    LeaveCriticalSection(&csClientList);
    return 0;        
}


/********************************************************************/
/* removeClient                                                     */
/*    Removes an existing client from the client list.              */
/*    Protected in a critical section.                              */
/********************************************************************/
void removeClient(SOCKET sock)
{
    int i;

    EnterCriticalSection(&csClientList);
    
    for (i=0; i<num_socks && socks[i] != sock; i++);
    
    if (i<num_socks)
    {
        for ( ; i<num_socks; i++)
            socks[i] = socks[i+1];
            
        num_socks--;            
    }
    LeaveCriticalSection(&csClientList);
}



/********************************************************************/
/* AcceptThread                                                     */
/*    Accepts new connections and creates new ClientThreads.        */
/*    Spends most of its time blocked by accept().                  */
/*    Never exits its loop; closed only by program's termination.   */
/********************************************************************/
void AcceptThread(void *x)
{
    SOCKET servSock;
    SOCKET clntSock;
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned int clntLen;            /* Length of client address struct */
    int     clntID = 1;
    struct ClientRec  rec;
    char sReport[RPTBUFSIZE+1];
    
    servSock = *(SOCKET*)x;
    clntLen = sizeof(echoClntAddr);

    /* Loop accepting new connections and creating new ClientThreads     */
    while (1)
    {
        /* Wait for a client to connect                                  */
        /* NOTE:                                                         */ 
        /*   This operation will block until a client connects, causing  */
        /*       the thread to "freeze" during that wait.                */
        if ((clntSock = accept(servSock, (struct sockaddr *) &echoClntAddr, 
                                &clntLen)) < 0)
            DieWithError("accept() failed");

        /* clntSock is connected to a client! */
        /* Report the connection to stdout    */
        sprintf(sReport,"Handling client %s\n", 
                        inet_ntoa(echoClntAddr.sin_addr));
        AddReport(sReport);
        
        if (addClient(clntSock) == -1)
        {
            sprintf(sReport,"Too many clients\n");
            AddReport(sReport);
        }
        else
        {
            sprintf(sReport,"%d clients currently connected\n",num_socks);
            AddReport(sReport);
            
            rec.sock = clntSock;
            rec.ID = clntID++;

            if (_beginthread(ClientThread, 0, (void*)&rec) == -1) 
            {
                fprintf(stderr, "Failed to start client thread");
            }
        }            
    }

    _endthread();
}


/********************************************************************/
/* ClientThread                                                     */
/*    Conducts the echo session with the client assigned to it.     */
/*    Spends most of its time blocked by recv().                    */
/*    Only exits when the client ends the session; otherwise        */
/*          closed by program's termination.                        */
/********************************************************************/
void ClientThread(void *x)
{
    SOCKET clntSock;
    int clntID;
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned int clntLen;            /* Length of client address struct */
    char echoBuffer[RCVBUFSIZE+1];        /* Buffer for echo string */
    char sReport[RPTBUFSIZE+1];
    int  recvMsgSize;                   /* Size of received message */
    int  send_failed;                   /* flag that the send() failed */
    
    clntSock = ((struct ClientRec*)x)->sock;
    clntID = ((struct ClientRec*)x)->ID;
    clntLen = sizeof(echoClntAddr);
    getpeername(clntSock, (struct sockaddr *) &echoClntAddr, &clntLen);

    /* Send received string and receive again until end of transmission */
    do   /* while (! send_failed && recvMsgSize > 0) */
    {
        /* Receive message from client */
        /* NOTE:                        */ 
        /*   This operation will block until it receives a message from  */
        /*       the client, causing the thread to "freeze" during that  */
        /*       wait.                                                   */
        recvMsgSize = recv(clntSock, echoBuffer, RCVBUFSIZE,0);
        sprintf(sReport,"Client #%d:  Received %d bytes\n", clntID,
                        recvMsgSize);
        AddReport(sReport);
        if (recvMsgSize < 0)
            CloseWithError(clntSock, "recv() failed");
        else if (!recvMsgSize) /* zero means the client is disconnecting */
        {
            /* Report the client's shutdown to stdout    */
            sprintf(sReport,"Client #%d shutting down\n", clntID);
            AddReport(sReport);
            shutdown(clntSock,1);    /* signal that we're done sending  */

            /* Winsock requires a special function for sockets */
            closesocket(clntSock);    /* Close client socket */
            removeClient(clntSock);

            /* Report the client's shutdown to stdout    */
            sprintf(sReport,"Closing client #%d\n", clntID);
            AddReport(sReport);
            sprintf(sReport,"%d clients currently connected\n",num_socks);
            AddReport(sReport);
        }
        /* Only if we actually received a message do we echo it back */
        if (recvMsgSize > 0)
        {

            /* Echo message back to client */
            /* NOTE:  blocks until the message is sent  */
            /*    Not normally a problem.               */
            if (send(clntSock, echoBuffer, recvMsgSize, 0) != recvMsgSize)
            {
                CloseWithError(clntSock, "send() failed");
                send_failed = 1;                /* break out of while loop  */
            }
            else
                send_failed = 0;
        }
    } while (! send_failed && recvMsgSize > 0);
    
    _endthread();
}


/********************************************************/
/* DieWithError                                         */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void DieWithError(char *errorMessage)
{
    ReportError(errorMessage);
    exit(1);
}

/********************************************************/
/* CloseWithError                                       */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void CloseWithError(SOCKET clntSocket, char *errorMessage)
{
    ReportError(errorMessage);
    /* Winsock requires a special function for sockets */
    closesocket(clntSocket);    /* Close client socket */
    removeClient(clntSocket);
}

/**************************************************************************/
/* ReportError                                                            */
/*    Displays a message that reports the error                           */
/*    Encapsulates the difference between UNIX and Winsock error handling */
/* Winsock Note:                                                          */
/*    WSAGetLastError() only returns the error code number without        */
/*    explaining what it means.  A list of the Winsock error codes        */
/*    is available from various sources, including Microsoft's            */
/*    on-line developer's network library at                              */
/*  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winsock/winsock/windows_sockets_error_codes_2.asp */
/**************************************************************************/
void ReportError(char *errorMessage)
{
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
}


/********************************************************************/
/* Report Pseudo-Object                                             */
/*    Maintains queue of output strings to be displayed.            */
/*    Strings are added by the threads and removed for display      */
/*          by the main thread.                                     */
/*    Protected in a critical section.                              */
/********************************************************************/

#define MAXREPORTS (MAXSOCKS * 5)
char sReports[MAXREPORTS][RPTBUFSIZE+1];
int  m_iNextIn = 0, m_iNextOut = 0;


/********************************************************************/
/* AddReport                                                        */
/*    Adds an output strings to the queue.                          */
/*    Protected in a critical section.                              */
/********************************************************************/
void AddReport(char *sRpt)
{
    EnterCriticalSection(&csReports);
    while ( ((m_iNextIn +1)% MAXREPORTS) == m_iNextOut)
    {
        LeaveCriticalSection(&csReports);
        Sleep(100);
        EnterCriticalSection(&csReports);
    }
    
    strcpy(sReports[m_iNextIn++], sRpt);
    if (m_iNextIn >= MAXREPORTS)
        m_iNextIn = 0;
    LeaveCriticalSection(&csReports);
}

/********************************************************************/
/* GetReport                                                        */
/*    Displays next output string and deletes it from the queue.    */
/*    Protected in a critical section.                              */
/********************************************************************/
void GetReport(void)
{
    // if both indices are equal, then report list is empty
    while (m_iNextIn != m_iNextOut)
    {
        printf("%s", sReports[m_iNextOut]);
        m_iNextOut = (m_iNextOut+1) % MAXREPORTS;
    }
}

/* End of File */

