#!/bin/bash
gcc -Wall -o $1 $1.c

