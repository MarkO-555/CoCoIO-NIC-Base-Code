This is some WizNet5100 Code for the Retro Challange 2016 using the Uthernet II on the Apple ][ and a Server based on Win32.
You can see the Text Version of some Merlin Source Code in the file, TCP_04.TXT

There are now Two Servers avaliable.
The "Server" Directory  is built in Open Watcom, for a Windows 32 Host.  You can use v1.9 to rebuild it.
http://ftp.openwatcom.com/download.php

Socket_Server_03.exe  should be on Port 20000.  You can connect with Telnet.



The "echo_apps" Directory is built with GCC on Linux and probable Windows, under CygWin or MSYS32.  

tcp_server01 can be Bound to any Port at runtime, ( that is not already in use ).
You can connect from the Local System or a Remote System.



