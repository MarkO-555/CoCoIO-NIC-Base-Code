/*************************************************************************/
/* udptimec.c                                                            */
/* David C. Wise, 2008                                                   */
/* Email: dwise1@aol.com                                                 */
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* Simple UDP Time and SNTP Client Example                               */
/* Sends a request to a time/NTP server and displays the response        */
/* Obtains the server and protocol/port arguments from the command-line  */
/* Contains code to resolve domain names and service names.              */
/* Can act as a broadcast client for the time service (UDP port 37)      */
/* Output designed for educational purposes; gives full hex dump and     */
/*     interprets all fields of the NTP message as well as calculating   */
/*     and displaying delay times.                                       */
/* Support applications also available:                                  */
/*      udptimed -- UDP time server (port 37)                            */
/*      btimed -- broadcast time server (port 37)                        */
/* Find list of NTP servers through the NTP support site,                */
/*      http://support.ntp.org/bin/view/Servers/WebHome                  */
/*************************************************************************/
/* Usage: udptimec [-h] {-b [<Port>] | <Server> [<Port>]}                */
/*                                                                       */
/*      Displays source of response message and number of bytes.         */
/*      Displays data in hex-dump format.                                */
/*      Interprets and displays time messages (port 37).                 */
/*      Interprets and displays all the fields of an NTP message.        */
/*      Accepts either IP address or domain name of server.              */
/*      Accepts either port number or service name                       */
/*              (ie, time, timserver, ntp).                              */
/*      If not specified, port defaults to time (37).                    */
/*      For time and ntp, receives a single response and terminates.     */
/*      As a broadcast client continues running and displaying time      */
/*          broadcasts; press ESC key to exit.                           */
/*      Options:                                                         */
/*          -h  help -- this screen.                                     */
/*          -b  broadcast client.                                        */
/*************************************************************************/
/* Actual sockets programming based on code examples from                */
/*      "The Pocket Guide to TCP/IP Sockets: C Version"                  */
/*                 by Michael J. Donahoo and Kenneth L. Calvert:         */
/*                                                                       */
/* The book's  original UNIX source code is freely available from        */
/*      their web site at                                                */
/*          http://cs.baylor.edu/~donahoo/PocketSocket/textcode.html     */
/*      and the Winsock version of the code at                           */
/*          http://cs.baylor.edu/~donahoo/PocketSocket/winsock.html      */
/*                                                                       */
/* Please read the authors' disclaimer on their web site at              */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/* In particular note that "the authors and the Publisher DISCLAIM ALL   */
/*      EXPRESS AND IMPLIED WARRANTIES, including warranties of          */
/*      merchantability and fitness for any particular purpose.          */
/* Your use or reliance upon any sample code or other information in     */
/*      [their] book will be at your own risk.                           */
/* No one should use any sample code (or illustrations) from [their]     */
/*      book in any software application without first obtaining         */
/*      competent legal advice."                                         */
/*************************************************************************/
/* Because conio was used for testing for the ESC key in TestForQuit(),  */
/*      this program is NOT portable to UNIX/Linux, but rather will only */
/*      compile with a Windows compiler that supports conio.             */
/* However, for educational purposes this code still uses the            */
/*      WINSOCK_EXAMPLE macro to allow compiling under UNIX/Linux.       */
/*      Be aware that if you exercise the UNIX/Linux option, then you    */
/*      will need to modify TestForQuit().                               */
/* The Winsock version will require the Winsock library to be linked in  */
/*      (exact method and library name are compiler-dependent;           */ 
/*       name is usually some form of winsock.lib or ws2_32.lib)         */
/*************************************************************************/

/*************************************************************************/
/* Sample Runs:

C:>udptimec localhost time
Sending 0-byte query to localhost:time [127.0.0.1:37]
Received 4 bytes from localhost [127.0.0.1:37]
CB 55 BD 68                                        .U.h
 **********
Universal Coordinated Time is Thu Feb 07 17:24:56 2008



C:>udptimec ntp.ucsd.edu ntp
Sending 48-byte query to ntp.ucsd.edu:ntp [132.239.1.6:123]
1B 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00    ................
00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00    ................
00 00 00 00 00 00 00 00 CB 55 BD 6E 8F 9D B2 2D    .........U.n...-
 **********
Received 48 bytes from bigben.ucsd.edu [132.239.1.6:123]
1C 01 00 EC 00 00 00 00 00 00 00 16 47 50 53 00    ............GPS.
CB 55 BD 67 32 DF 61 24 CB 55 BD 6E 8F 9D B2 2D    .U.g2.a$.U.n...-
CB 55 BD 6E 9B 36 9B 9D CB 55 BD 6E 9B 4E 54 F7    .U.n.6...U.n.NT.
 **********
Flags: 0x1C  LI: no warning (0)  Ver 3  Mode: server (4)
Peer Clock Stratum: primary reference (1)
Peer Polling Interval: 1 (0)
Peer Clock Precision: 9.53674e-007 (-20)
Root Delay: 0 (00000000)
Clock Dispersion: 0.000335693 (00000016)
Reference Clock ID: 'GPS'
Reference Clock Update Time: 2008-02-07 17:24:55.1987 UTC (CB55BD67 32DF6124)
Originate Time Stamp: 2008-02-07 17:25:02.5610 UTC (CB55BD6E 8F9DB22D)
Receive Time Stamp: 2008-02-07 17:25:02.6063 UTC (CB55BD6E 9B369B9D)
Transmit Time Stamp: 2008-02-07 17:25:02.6067 UTC (CB55BD6E 9B4E54F7)
Destination Time: 2008-02-07 17:25:02.608 UTC
Round Trip Delay: 0.047362
Local Clock Offset: 0.021983

*/
/*************************************************************************/

/****************************************************************/

/* #define for Windows; #undef for UNIX/Linux                   */
/* WARNING:  if you #undef it, you need to modify TestForQuit() */
#define WINSOCK_EXAMPLE

#include <stdlib.h>     /* for exit() */
#include <stdio.h>      /* for printf(), fprintf() */
#include <string.h>     /* for string functions  */
#include <ctype.h>     /* for exit() */
#include <math.h>     /* for exit() */
#include <time.h>     /* for exit() */
#include <malloc.h>     /* for exit() */
#include <sys/timeb.h>
#ifdef WINSOCK_EXAMPLE
#include <conio.h>       /* for kbhit() */
#include <winsock2.h>    /* for socket(),... */
#else
#include <unistd.h>     /* for close() */
#include <sys/socket.h> /* for socket(),... */
#include <netinet/in.h> /* for socket(),... */
#include <arpa/inet.h>  /* for inet_addr() */
#endif    



/* *****  GLOBALS  ***** */

#define FALSE    0
#define TRUE    1
#define BUFFERMAX 512           /* Largest possible size of a datagram */
#define NTP_PACKET_SIZE  48
#define TIME_PACKET_SIZE  4

/* Uncomment if BOOL is not defined in your system */
/* typedef unsigned char BOOL; */


/* Settings */
char    *m_IPaddr = NULL;
char    *m_hostname = NULL;
char    *m_service = NULL;
unsigned short  m_port = 0;
BOOL     m_bBroadcastClient = FALSE;

/* *****  PROTOTYPES  ***** */

/* Operational Functions */
void RunSession(void);
void RunClient(void);
void RunBroadcastClient(void);


/* Time Message Functions */
int PrepareQueryPayload(unsigned char *buffer);
int PrepareNTPqueryPayload(unsigned char *buffer);
time_t ReportNTPresponse(unsigned char *buffer);
time_t DisplayTimeMessage(unsigned char *buffer,int len);
void DisplayResponse(unsigned char *buffer,int respLen,struct sockaddr_in *fromAddr);


/* Sockets support */
int IsAddress(char *s);
char *GetHostName(char **name,struct sockaddr_in *addr);
char *ResolveHostAddress(char *data,char **addr,char **name);
unsigned short ResolveService(char *data, char **service, char *protocol);
void DieWithError(char *errorMessage);


/* Support Functions */
BOOL ParseCommandLine(int argc, char *argv[]);
BOOL ResolveArguments(void);
const char *GetUsageMessage(void);
void DisplayManPage(void);
//void WriteHexLine(int nBytes, unsigned char a[]);
void HexDump(unsigned char *buffer,int len);
BOOL TestForQuit(void);


/* ***************  CODE  *************** */

/********************************************************************/
/* main -- like opinions, every program has one.                    */
/********************************************************************/
int main(int argc, char *argv[])
{
#ifdef WINSOCK_EXAMPLE
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */ 
#endif

    /* Parse the command line and check for errors.     */
    /* If any error found, exit with the usage message. */
    if (ParseCommandLine(argc, argv) == FALSE)
    {
        fprintf(stderr,GetUsageMessage());
        exit(1);
    }

#ifdef WINSOCK_EXAMPLE
    /* Winsock requires explicit DLL and library initialization  */
    /* If Winsock startup fails, exit with an error message.     */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }
#endif

    /* Now resolve the server name and service name     */
    /*      to an IP address and port number.           */ 
    /* If any error found, exit with the usage message. */
    /* This function call has to follow WSAStartup,     */
    /*      because it requires Winsock support.        */ 
    if (ResolveArguments() == FALSE)
    {
        fprintf(stderr,GetUsageMessage());
        exit(1);
    }

    /* Now we have everything we need to conduct our session */
    RunSession();

#ifdef WINSOCK_EXAMPLE
    /* Winsock requires explicit unloading of the DLL  */
    WSACleanup();  /* Cleanup Winsock */
#endif    

    return 0;
}



/********************************************************************/
/* RunSession                                                       */
/*    Depending on whether the broadcast option was entered,        */
/*          run either the broadcast client or the regular client.  */
/********************************************************************/
void RunSession(void)
{
    if (m_bBroadcastClient == TRUE)
        RunBroadcastClient();
    else
        RunClient();
}


/********************************************************************/
/* RunClient                                                        */
/*    As a regular time client, sends a request to a server,        */
/*          receives and displays the response.                     */
/*    Does not loop, but rather only conducts a single transaction  */
/*          and then exits immediately.                             */
/********************************************************************/
void RunClient(void)
{
#ifdef WINSOCK_EXAMPLE
    SOCKET sock;                        /* Socket */
#else
    int    sock;                        /* Socket descriptor */
#endif    
    struct sockaddr_in serverAddr;      /* server address */
    struct sockaddr_in fromAddr;        /* Source address of response */
    unsigned char buffer[BUFFERMAX];    /* Buffer for response */
    int bufferLen;                      /* Length of query  */
    int respLen;                        /* Length of response */
    int fromSize;

    /* Create a best-effort datagram socket using UDP */
#ifdef WINSOCK_EXAMPLE
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
#else
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
#endif    
        DieWithError("socket() failed");

    /* Construct the server address structure */
    memset(&serverAddr, 0, sizeof(serverAddr));    /* Zero out structure */
    serverAddr.sin_family = AF_INET;            /* Internet address family */
    serverAddr.sin_addr.s_addr = inet_addr(m_IPaddr); /* Server IP address */
    serverAddr.sin_port   = htons(m_port);     /* Server port */

    /* prepare the query packet */
    bufferLen = PrepareQueryPayload(buffer);

    /* report the sending of the query packet, along with its hex dump */
    printf("Sending %d-byte query to %s:%s [%s:%d]\n",bufferLen,
                m_hostname,m_service,
                m_IPaddr,m_port);
    if (bufferLen)
        HexDump(buffer,bufferLen);

    /* Send the query to the server */
    if (sendto(sock, (char *)buffer, bufferLen, 0, (struct sockaddr *)
                   &serverAddr, sizeof(serverAddr)) < bufferLen)
        DieWithError("sendto() sent a different number of bytes than expected");

    /* Recv a response */
    fromSize = sizeof(fromAddr);
    if ((respLen = recvfrom(sock, (char *)buffer, BUFFERMAX, 0, 
                    (struct sockaddr *) &fromAddr, (int *)&fromSize)) <= 0)
        DieWithError("recvfrom() failed");

    /* safety check that the response came from the server we queried */
    if (serverAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
    {
        fprintf(stderr,"Error: received a packet from unknown source.\n");
    }

    /* display the response */
    DisplayResponse(buffer,respLen,&fromAddr);

    /* Close client socket */
#ifdef WINSOCK_EXAMPLE
    /* Winsock requires a special function for sockets */
    closesocket(sock);   
#else
    /* Everything is a file in UNIX, so one function fits all */
    close(sock);    
#endif    
}


/********************************************************************/
/* RunBroadcastClient                                               */
/*    As a broadcast time client, binds to the port and waits for   */
/*          a packet to arrive.                                     */
/*    When it receives a packet, it reports that fact and from      */
/*          whom, and then displays the data received.              */
/*    Returns to waiting for the next packet to arrive.             */
/*                                                                  */
/*    Runs in an infinite loop, waiting indefinitely for packets.   */
/*    To exit the loop, press the ESC key.                          */
/*    If no packets are being received, then cancel out with Ctrl-C */
/********************************************************************/
void RunBroadcastClient(void)
{
#ifdef WINSOCK_EXAMPLE
    SOCKET sock;                        /* Socket */
#else
    int    sock;                        /* Socket descriptor */
#endif    
    struct sockaddr_in broadcastAddr; /* Echo server address */
    unsigned char buffer[BUFFERMAX];        /* Buffer for echo string */
    int     respLen;               /* Length of response string */
    struct sockaddr_in fromAddr;     /* Source address of echo */
    int     fromSize;

    /* Create a best-effort datagram socket using UDP */
#ifdef WINSOCK_EXAMPLE
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
#else
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
#endif    
        DieWithError("socket() failed");

    /* Construct bind structure */
    memset(&broadcastAddr, 0, sizeof(broadcastAddr)); /* Zero out structure */
    broadcastAddr.sin_family = AF_INET;         /* Internet address family */
    broadcastAddr.sin_addr.s_addr = htonl(INADDR_ANY);  /* Any interface */
    broadcastAddr.sin_port = htons(m_port);      /* Broadcast port */

    /* report our progress */
    printf("Setting up broadcast client on port %d [%s]\n",
            m_port,m_service);

    /* Bind to the broadcast port */
    if (bind(sock, (struct sockaddr *) &broadcastAddr, sizeof(broadcastAddr)) < 0)
        DieWithError("bind() failed");

    /* loop infinite */
    while (1)
    {
        /* test whether the ESC key has been pressed.  */
        /* If so, then break out of loop and exit */
        if (TestForQuit() == TRUE)
            break;

        /* Receive a single datagram from the server */
        fromSize = sizeof(fromAddr);
        if ((respLen = recvfrom(sock, (char *)buffer, BUFFERMAX, 0, 
                    (struct sockaddr *) &fromAddr, (int *)&fromSize)) < 0)
            DieWithError("recvfrom() failed");

        /* display the response */
        DisplayResponse(buffer,respLen,&fromAddr);
    }

    /* Close client socket */
#ifdef WINSOCK_EXAMPLE
    /* Winsock requires a special function for sockets */
    closesocket(sock);    /* Close client socket */
#else
    close(sock);    /* Close client socket */
#endif    
}


/**********************************************************************/
/* time functions                                                     */
/**********************************************************************/


/**********************************************************************/
/* PrepareQueryPayload                                                */
/*    Prepares the query in the buffer and returns the query length.  */
/*                                                                    */
/*    Interesting Side Effect:                                        */
/*      Since it only tests explicitly for the NTP port, this allows  */
/*          you to query the server of any UDP protocol that accepts  */
/*          a zero-length query, such as daytime (port 13, RFC 867)   */
/*          and "Quote of the day" (AKA "qtod" or "quote", port 17,   */
/*          RFC 865).  This will enable you to examine a hex dump     */
/*          of their responses.                                       */
/**********************************************************************/
int PrepareQueryPayload(unsigned char *buffer)
{
    int len;

    if (m_port == 123)    /* NTP port number is 123 */
        len = PrepareNTPqueryPayload(buffer);
    else
        len = 0;          /* time protocol has zero-length query */

    return len;
}


/***************************************************************************/
/* DisplayResponse                                                         */
/*    Displays the response from the server:                               */
/*          The server's address, port, and the length of the message.     */
/*          A hex dump of the response itself.                             */
/*          An interpretation of the response data (only for ntp or time). */
/*                                                                         */
/*    Side Effect:                                                         */
/*      Since this function does test explicitly for the port number and   */
/*          only interprets the standard ports for the time and NTP        */
/*          protocols, that means that if you use any port different from  */
/*          the defaults, then the program will fail to interpret the      */
/*          response data.  It will still report the server data and still */
/*          display a hex dump of the data, but it will not interpret the  */
/*          data.                                                          */
/***************************************************************************/
void DisplayResponse(unsigned char *buffer,int respLen,
                        struct sockaddr_in *fromAddr)
{
    char FromIP[20];                    /* IP address of server */
    unsigned short fromPort;
    char *name;
    char HostName[81];
    time_t Time;

    /* get the server's address and port */
    fromPort = ntohs(fromAddr->sin_port);            /* Server port */
    strcpy(FromIP,inet_ntoa(fromAddr->sin_addr));    /* IP address of server */

    /* get the host's name via DNS reverse lookup */
    if (GetHostName(&name,fromAddr) == NULL)
        sprintf(HostName,"%s:%d",FromIP,fromPort);
    else
    {
        sprintf(HostName,"%s [%s:%d]",name,FromIP,fromPort);
        free(name);
    }

    /* display the host's name and IP and port */
    printf("Received %d bytes from %s\n",respLen,HostName);

    /* display hex dump of the response packet */
    HexDump(buffer,respLen);

    /* interpret the response data, based on port number */
    /* Please note that if it's any other port number,  
            then the data will not be interpreted.       */
    switch (m_port)
    {
      case 37:
        Time = DisplayTimeMessage(buffer,respLen);
        break;
      case 123:
        Time = ReportNTPresponse(buffer);
        break;
    }
}


/************************************************************/
/*  AdjTimeToUNIX                                           */
/*  AdjTimeToNTP                                            */
/*      These functions convert time values from UNIX time  */
/*          to NTP/timserver and back.                      */
/*      Time in the time protocols are expressed as number  */
/*          of seconds since midnight 1900 January 01.      */
/*          However, C's time functions are based on UNIX   */
/*          time, which is the number of seconds since      */
/*          midnight 1970 Jan 01.  So when we receive time  */
/*          from a server, we need to convert it to UNIX    */
/*          time before our system can use it.              */
/*      The time protocol RFC, RFC 868, gives the time at   */
/*          midnight 1970 Jan 01 as being 2,208,988,800,    */
/*          so that is our conversion offset.               */
/*                                                          */
/*      BTW, MS-DOS time was based on midnight 1980 Jan 01, */
/*          around when the first IBM PC's came out.        */
/************************************************************/
#define TIME_OFFSET_1970  2208988800UL

unsigned long AdjTimeToUNIX(unsigned long t)
{
    return t - TIME_OFFSET_1970;
}

unsigned long AdjTimeToNTP(unsigned long t)
{
    return t + TIME_OFFSET_1970;
}


/***************************************************************************/
/* DisplayTimeMessage                                                      */
/*    Interprets and displays the response from a Time server (port 37).   */
/*                                                                         */
/*    This function returns the time received as a UNIX time_t value, so   */
/*          that the program would be able to use it.  It just so happens  */
/*          that this program does not.                                    */
/***************************************************************************/
time_t DisplayTimeMessage(unsigned char *buffer,int len)
{
    struct tm *newtime;
    unsigned long ulTime;

    /* error check for bogus data */
    if (len != TIME_PACKET_SIZE)
    {
        printf("Wrong format for Time Message.\n\n");
        return 0L;
    }

    /* convert the data from network byte order to host byte order */
    /* this is a manual method; could have just as easily used ntohl() */    
    ulTime =  (unsigned long)( (unsigned char)buffer[0]) << 24; 
    ulTime |= (unsigned long)( (unsigned char)buffer[1]) << 16; 
    ulTime |= (unsigned long)( (unsigned char)buffer[2]) << 8;  
    ulTime |= (unsigned long)( (unsigned char)buffer[3] );      

    /* the time we received was Time protocol time based on 1900 */
    /* convert it to UNIX time based on 1970 */
    ulTime = AdjTimeToUNIX(ulTime);

    /* Obtain Universal Coordinated Time:                   */
    /*   load a struct tm with the time data and display it */
    newtime = gmtime((long *)&ulTime );
    printf( "Universal Coordinated Time is %s\n\n", asctime( newtime ) );
    return (time_t)ulTime;
}



/**********************************************************/
/* struct NTPpayload                                      */
/*      used to represent the data in an NTP packet       */
/*                                                        */
/* Format (48 bytes):                                     */
/* 00  Flags:                                             */
/*     00.. .... Leap indicator: no warning               */
/*     ..00 1... Version Number: reserved                 */
/*     .... .011 Mode: client                             */
/* 01  Peer Clock Stratum: unspecified (0)                */
/* 02  Peer Polling Interval: invalid (0)                 */
/* 03  Peer Clock Precision: 1.000000 sec                 */
/* 04  Root Delay: 0.0000 sec                             */
/* 08  Clock Dispersion: 0.0000 sec                       */
/* 12  Reference Clock ID: unidentifed ref source ''      */
/* 16  Reference Clock Update Time: NULL                  */
/* 24  Originate Time Stamp: 2002-07-18 14:02:09.3300 UTC */
/* 32  Receive Time Stamp: NULL                           */
/* 40  Transmit Time Stamp: NULL                          */
/**********************************************************/
typedef struct 
{
    unsigned char    Flags;
    unsigned char    LeapIndicator;
    unsigned char    VersionNumber;
    unsigned char    Mode;
    unsigned char    PeerClockStratum;
    unsigned char    PeerPollingInterval;
    signed char      PeerClockPrecision;
    long             RootDelay;
    long             ClockDispersion;
    char             ReferenceClockID[5];
    unsigned long    ReferenceClockUpdateTime[2];
    unsigned long    OriginateTimeStamp[2];
    unsigned long    ReceiveTimeStamp[2];
    unsigned long    TransmitTimeStamp[2];
} NTPpayload;


/**********************************************************************/
/* ConstructNTPpayload                                                */
/*    Constructs an NTP data packet by inserting the field data in    */
/*          the NTPpayload struct into the buffer.                    */
/*                                                                    */
/*    The method employed for multi-byte integer fields:              */
/*        1. Take the address of the i'th element of the buffer       */  
/*                 eg, &buffer[16]                                    */
/*        2. Cast that address as a pointer to the data type          */
/*                 eg, (unsigned long*)(&buffer[40])                  */
/*        3. Dereference that pointer                                 */
/*                 eg, *((unsigned long*)(&buffer[40]))               */
/*        4. Convert the unsigned long value to network byte order    */
/*                 eg, htonl(data->TransmitTimeStamp[0])              */
/*        5. Assign the value to the derefereced pointer              */
/*                 eg, *((unsigned long*)(&buffer[40])) =             */
/*                                 htonl(data->TransmitTimeStamp[0]); */
/**********************************************************************/
void ConstructNTPpayload(NTPpayload *data,unsigned char *buffer)
{
    int i;

    /* just to keep packet format issues in one place */
    data->Flags = (data->LeapIndicator << 6) & 0xC0;
    data->Flags |= (data->VersionNumber << 3) & 0x38;
    data->Flags |= data->Mode & 0x07;
    
    buffer[0] = data->Flags;
    buffer[1] = data->PeerClockStratum;
    buffer[2] = data->PeerPollingInterval;
    buffer[3] = data->PeerClockPrecision;
    *((long*)(&buffer[4])) = htonl(data->RootDelay);
    *((long*)(&buffer[8])) = htonl(data->ClockDispersion);
    for (i=0; i<4; i++)
        buffer[12+i] = data->ReferenceClockID[i];
    *((unsigned long*)(&buffer[16])) = htonl(data->ReferenceClockUpdateTime[0]);
    *((unsigned long*)(&buffer[20])) = htonl(data->ReferenceClockUpdateTime[1]);
    *((unsigned long*)(&buffer[24])) = htonl(data->OriginateTimeStamp[0]);
    *((unsigned long*)(&buffer[28])) = htonl(data->OriginateTimeStamp[1]);
    *((unsigned long*)(&buffer[32])) = htonl(data->ReceiveTimeStamp[0]);
    *((unsigned long*)(&buffer[36])) = htonl(data->ReceiveTimeStamp[1]);
    *((unsigned long*)(&buffer[40])) = htonl(data->TransmitTimeStamp[0]);
    *((unsigned long*)(&buffer[44])) = htonl(data->TransmitTimeStamp[1]);
}


/***********************************************************************/
/* ParseNTPpayload                                                     */
/*    Extract data from an NTP data packet and transfer it to an       */
/*          NTPpayload struct.                                         */
/*                                                                     */
/*    The method employed for multi-byte integer fields is pretty      */
/*          much the same as in ConstructNTPpayload:                   */
/*              Take the address of the i'th element of the buffer,    */  
/*                  cast to a pointer to the data type, dereference    */
/*                  it, then pass it to ntohl() to convert it to       */
/*                  host byte order and assign it to the struct field. */
/***********************************************************************/
void ParseNTPpayload(NTPpayload *data,unsigned char *buffer)
{
    int i;

    /* just to keep packet format issues in one place  */
    data->Flags = buffer[0];
    data->LeapIndicator = (data->Flags >> 6) & 0x03;
    data->VersionNumber = (data->Flags >> 3) & 0x07;
    data->Mode = data->Flags & 0x07;
    
    data->PeerClockStratum = buffer[1];
    data->PeerPollingInterval = buffer[2];
    data->PeerClockPrecision = buffer[3];
    data->RootDelay = ntohl(*((long*)(&buffer[4])));
    data->ClockDispersion = ntohl(*((long*)(&buffer[8])));
    for (i=0; i<4; i++)
        data->ReferenceClockID[i] = buffer[12+i];
    data->ReferenceClockID[4] = '\0';    /* null-terminate it */
    data->ReferenceClockUpdateTime[0] = ntohl(*((unsigned long*)(&buffer[16])));
    data->ReferenceClockUpdateTime[1] = ntohl(*((unsigned long*)(&buffer[20])));
    data->OriginateTimeStamp[0] = ntohl(*((unsigned long*)(&buffer[24])));
    data->OriginateTimeStamp[1] = ntohl(*((unsigned long*)(&buffer[28])));
    data->ReceiveTimeStamp[0] = ntohl(*((unsigned long*)(&buffer[32])));
    data->ReceiveTimeStamp[1] = ntohl(*((unsigned long*)(&buffer[36])));
    data->TransmitTimeStamp[0] = ntohl(*((unsigned long*)(&buffer[40])));
    data->TransmitTimeStamp[1] = ntohl(*((unsigned long*)(&buffer[44])));
}


/************************************************************************/
/* PrepareNTPqueryPayload                                               */
/*    Prepare an NTP data packet to be used in a query message.         */
/*    Calls ConstructNTPpayload() to create the actual data packet.     */
/*    Returns the size of the data packet thus created.                 */
/*                                                                      */
/*    In an NTP query packet, all fields are set to zero except:        */
/*          Version Number <- 3                                         */
/*          Mode <- Client (3)                                          */
/*          Transmit Timestamp <- current system time                   */
/*                                                                      */
/*    In the response, the Transmit Timestamp will be returned as the   */
/*          Originate Timestamp so that we can calculate the            */
/*          transmission delay times.                                   */
/*    We use the _ftime() library function instead of time(), because   */
/*          it gives us the system time down to milliseconds whereas    */
/*          time() only gives it down to the second.                    */
/*    The second 32-bit word of the time stamp is in fractions of a     */
/*          second, so to convert the milliseconds into an unsigned     */
/*          long that represents that value, we need to effectively     */
/*          convert them to seconds (divide by 1000) and then shift     */
/*          them left by 32 bits (multiply by 4,294,967,296).           */
/*          We accomplish this by casting the milliseconds to a double, */
/*          multipying them by 4294967.296, and then casting that       */
/*          product as an unsigned long.                                */
/************************************************************************/
int PrepareNTPqueryPayload(unsigned char *buffer)
{
    NTPpayload      data;
    int             i;
    struct _timeb   Time;

    data.LeapIndicator = 0;
    data.VersionNumber = 3;
    data.Mode = 3;        /* client */
    data.PeerClockStratum = 0;
    data.PeerPollingInterval = 0;
    data.PeerClockPrecision = 0;
    data.RootDelay = 0;
    data.ClockDispersion = 0L;
    for (i=0; i<4; i++)
        data.ReferenceClockID[i] = '\0';
    data.ReferenceClockUpdateTime[0] = 0L;
    data.ReferenceClockUpdateTime[1] = 0L;
    data.OriginateTimeStamp[0] = 0L;
    data.OriginateTimeStamp[1] = 0L;
    data.ReceiveTimeStamp[0] = 0L;
    data.ReceiveTimeStamp[1] = 0L;

    _ftime(&Time);
    data.TransmitTimeStamp[0] = AdjTimeToNTP(Time.time);
    data.TransmitTimeStamp[1] = 
                        (unsigned long)((double)Time.millitm * 4294967.296); 

    ConstructNTPpayload(&data,buffer);
    return NTP_PACKET_SIZE;
}


/************************************************************************/
/* BuildTimeString                                                      */
/*    Takes the two unsigned long fields of a time stamp and constructs */
/*          a time string of the format:                                */
/*                  yyyy-mm-dd HH:MM:SS.mmmm UTC                        */
/*                                                                      */
/*    Parameters:                                                       */
/*          s -- the string in which to build the time string           */
/*                  it's up to the caller to make it big enough         */
/*          x -- the first half of the time stamp, the integer part     */
/*          y -- the second half of the time stamp, the fractional part */
/************************************************************************/
char *BuildTimeString(char *s,unsigned long x, unsigned long y)
{
    struct tm *newtime;
    unsigned long ulTime;
    int    frac;

    /* if the timestamp does not contain an actual value, then bypass */
    if (x == 0L)
        strcpy(s,"NULL");
    else
    {
        /* convert the NTP time based on 1900 to UNIX time */
        ulTime = AdjTimeToUNIX(x);

        /* Obtain Universal Coordinated Time, AKA "GMT": */
        newtime = gmtime((long *)&ulTime );

        /* convert the fractional part into 10,000'ths of a second, rounded */
        frac = (int)(((double)y / 429496.7296)+0.5);

        /* build the string */
        sprintf(s,"%4d-%02d-%02d %02d:%02d:%02d.%04d UTC",
                newtime->tm_year+1900,newtime->tm_mon+1,newtime->tm_mday,
                newtime->tm_hour,newtime->tm_min,newtime->tm_sec,frac);
    }

    return s;
}


/************************************************************************/
/* BuildTime                                                            */
/*    Converts the two unsigned long fields of a time stamp to a double */
/*                                                                      */
/*    Parameters:                                                       */
/*          x -- the first half of the time stamp, the integer part     */
/*          y -- the second half of the time stamp, the fractional part */
/*    Returns:                                                          */
/*          The time in seconds as a double.                            */
/************************************************************************/
double BuildTime(unsigned long x, unsigned long y)
{
    unsigned long ulTime;
    double     frac;
    double   d;

    if (x == 0L)
        return 0.0;
    
    ulTime = AdjTimeToUNIX(x);

    frac = (double)y / 4294967296.0;
    d = (double)ulTime + frac;

    return d;
}


/************************************************************************/
/* ReportTimeDelay                                                      */
/*    For NTP, calculates and displays the Destination Timestamp and    */
/*          the Round Trip Delay and Local Clock Offset as described    */
/*          in RFC 2030, "5. SNTP Client Operations":                   */
/*----------------------------------------------------------------------*/
/*   When the server reply is received, the client determines a         */
/*   Destination Timestamp variable as the time of arrival according to */
/*   its clock in NTP timestamp format. The following table summarizes  */
/*   the four timestamps.                                               */
/*                                                                      */
/*      Timestamp Name          ID   When Generated                     */
/*      ------------------------------------------------------------    */
/*      Originate Timestamp     T1   time request sent by client        */
/*      Receive Timestamp       T2   time request received by server    */
/*      Transmit Timestamp      T3   time reply sent by server          */
/*      Destination Timestamp   T4   time reply received by client      */
/*                                                                      */
/*   The roundtrip delay d and local clock offset t are defined as      */
/*                                                                      */
/*      d = (T4 - T1) - (T2 - T3)     t = ((T2 - T1) + (T3 - T4)) / 2.  */
/************************************************************************/
void ReportTimeDelay(NTPpayload *data)
{
    struct _timeb Time;
    struct tm *newtime;
    double d, t;
    double t1, t2, t3, t4;

    _ftime(&Time);

    /* Obtain Universal Coordinated Time, AKA "GMT": */
    newtime = gmtime((long *)&Time.time);
    printf("Destination Time: %4d-%02d-%02d %02d:%02d:%02d.%03d UTC\n",
            newtime->tm_year+1900,newtime->tm_mon+1,newtime->tm_mday,
            newtime->tm_hour,newtime->tm_min,newtime->tm_sec,Time.millitm);

    /* calculate Destination Time */
    t4 = (double)Time.time + ((double)Time.millitm)/1000.0;

    t1 = BuildTime(data->OriginateTimeStamp[0],data->OriginateTimeStamp[1]);
    t2 = BuildTime(data->ReceiveTimeStamp[0],data->ReceiveTimeStamp[1]);
    t3 = BuildTime(data->TransmitTimeStamp[0],data->TransmitTimeStamp[1]);
    
    d = (t4 - t1) - (t2 - t3);
    t = ((t2 - t1) + (t3 - t4)) / 2.0;

    printf("Round Trip Delay: %f\n",d);
    printf("Local Clock Offset: %f\n\n",t);
}


/********************************************************/
/* literal strings used by ReportNTPresponse            */
/********************************************************/
const char *LeapIndicatorStrings[] = {"no warning",
                                    "last minute has 61 sec",
                                    "last minute has 59 sec",
                                    "alarm condition"
                                    };

const char *ModeStrings[] = {"reserved",
                            "symmetric active",
                            "symmetric passive",
                            "client",
                            "server",
                            "broadcast",
                            "reserved",
                            "reserved"
                            };


/************************************************************************/
/* ReportNTPresponse                                                    */
/*    Interprets and displays the contents of the NTP data packet.      */
/*                                                                      */
/*    Calls ParseNTPpayload to extract the data out of the data packet  */
/*    Prints out each line of the interpretation report, calling        */
/*          BuildTimeString for the timestamps.                         */
/*          a time string of the format:                                */
/*                  yyyy-mm-dd HH:MM:SS.mmmm UTC                        */
/*                                                                      */
/*    Parameters:                                                       */
/*          buffer -- the NTP data packet                               */
/*    Returns:                                                          */
/*          The time reported by the NTP server.                        */
/************************************************************************/
time_t ReportNTPresponse(unsigned char *buffer)
{
    NTPpayload  data;
    int            i;
    char        s[80];

    ParseNTPpayload(&data,buffer);

    printf("Flags: 0x%02X  LI: %s (%d)  Ver %d  Mode: %s (%d)\n",
            data.Flags, LeapIndicatorStrings[data.LeapIndicator],
            data.LeapIndicator, data.VersionNumber,
            ModeStrings[data.Mode], data.Mode);
    if (data.PeerClockStratum == 0)
        strcpy(s,"unspecified or unavailable");
    else if (data.PeerClockStratum == 1)
        strcpy(s,"primary reference");
    else if (data.PeerClockStratum == 0)
        strcpy(s,"primary reference");
    else 
        strcpy(s,"reserved");
    printf("Peer Clock Stratum: %s (%d)\n",s,data.PeerClockStratum);
    printf("Peer Polling Interval: %d (%d)\n",(int)pow(2,data.PeerPollingInterval),
            data.PeerPollingInterval);
    printf("Peer Clock Precision: %g (%d)\n",pow(2.0,data.PeerClockPrecision),
            data.PeerClockPrecision);
    printf("Root Delay: %g (%08lX)\n",(double)data.RootDelay/65536.0,data.RootDelay);
    printf("Clock Dispersion: %g (%08lX)\n",(double)data.ClockDispersion/65536.0,
            data.ClockDispersion);
    printf("Reference Clock ID: '");
    for (i=0; i<4 && data.ReferenceClockID[i] != '\0'; i++)
        printf("%c",data.ReferenceClockID[i]);
    printf("'\n");

    printf("Reference Clock Update Time: %s (%08lX %08lX)\n",
            BuildTimeString(s,data.ReferenceClockUpdateTime[0],data.ReferenceClockUpdateTime[1]),
            data.ReferenceClockUpdateTime[0],data.ReferenceClockUpdateTime[1]);
    printf("Originate Time Stamp: %s (%08lX %08lX)\n",
            BuildTimeString(s,data.OriginateTimeStamp[0],data.OriginateTimeStamp[1]),
            data.OriginateTimeStamp[0],data.OriginateTimeStamp[1]);
    printf("Receive Time Stamp: %s (%08lX %08lX)\n",
            BuildTimeString(s,data.ReceiveTimeStamp[0],data.ReceiveTimeStamp[1]),
            data.ReceiveTimeStamp[0],data.ReceiveTimeStamp[1]);
    printf("Transmit Time Stamp: %s (%08lX %08lX)\n",
            BuildTimeString(s,data.TransmitTimeStamp[0],data.TransmitTimeStamp[1]),
            data.TransmitTimeStamp[0],data.TransmitTimeStamp[1]);

    ReportTimeDelay(&data);

    return AdjTimeToUNIX(data.ReferenceClockUpdateTime[0]);
}


/************************************************************/
/* Sockets Support Functions                                */
/************************************************************/


/************************************************************/
/* IsAddress                                                */
/*    Tests whether a string contains a valid IP address.   */
/*                                                          */
/*    Parameters:                                           */
/*          s -- string containing a dotted-decimal address */
/*    Returns:                                              */
/*          TRUE -- string contains a valid address         */
/*          FALSE -- string does not                        */
/*                                                          */
/*  CAVEAT:                                                 */
/*      The test is performed by calling inet_addr.         */
/*          This function is being replaced; refer to the   */
/*          function's man pages either on your system or   */
/*          via Google.                                     */
/*      The INADDR_NONE failure value is defined on my      */
/*          system as 0xFFFFFFFF, which is also the -1      */
/*          failure value in UNIX documentation.  It is     */
/*          also a valid value for the common broadcast     */
/*          address of 255.255.255.255, and so the          */
/*          IsAddrees function will give a false failure    */
/*          for that one address.                           */
/************************************************************/
BOOL IsAddress(char *s)
{
    return (inet_addr(s) == INADDR_NONE) ? FALSE : TRUE;
}
 
 
/**************************************************************/
/* GetHostName                                                */
/*    Performs reverse DNS lookup to obtain the host name     */
/*          for a given IP address.                           */
/*                                                            */
/*    Parameters:                                             */
/*          name -- pointer to a string that the function     */
/*                  will create and fill with the host name.  */
/*          addr -- pointer to a sockaddr_in that contains    */
/*                  the host's address data.                  */
/*    Returns:                                                */
/*          char* to the name string, so that the function    */
/*                  could be used in a function call.         */
/*          NULL if the reverse look-up fails.                */
/*                                                            */
/*    CAVEAT:                                                 */
/*          Dynamically allocates memory for the name string, */
/*              so it's up to the calling function to free    */
/*              that memory up when it's done with it.        */
/**************************************************************/
char *GetHostName(char **name,struct sockaddr_in *addr)
{
    struct hostent *he;

    he = gethostbyaddr((char*)&addr->sin_addr,sizeof(addr->sin_addr),addr->sin_family);
    
    if (he == NULL)
    {
        *name = NULL;
    }
    else if (he->h_name == NULL)
    {
        *name = NULL;
    }
    else    /* successful */
    {
        *name = malloc(strlen(he->h_name)+1);
        strcpy(*name,he->h_name);
    }

    return *name;
}


/**************************************************************/
/* ResolveHostAddress                                         */
/*    Given a host name or IP address, resolve it so that     */
/*          we end up with both a host name and IP address.   */
/*                                                            */
/*    Parameters:                                             */
/*          data -- string containing the input data.         */
/*          addr -- pointer to a string that the function     */
/*                  will create and fill with the IP address. */
/*          name -- pointer to a string that the function     */
/*                  will create and fill with the host name.  */
/*    Returns:                                                */
/*          char* to the IP address, so that the function     */
/*                  could be used in a function call.         */
/*          NULL if the look-up fails.                        */
/*                                                            */
/*    CAVEAT:                                                 */
/*          Dynamically allocates memory for both the name    */
/*              string and the IP address string, so it's     */
/*              up to the calling function to free that       */
/*              memory up when it's done with it.             */
/**************************************************************/
char *ResolveHostAddress(char *data,char **addr,char **name)
{
    struct hostent *he;
    struct sockaddr_in saddr;
#ifndef WINSOCK_EXAMPLE
    char   s[80];
#endif

    if (IsAddress(data) == TRUE)
    {
        *addr = malloc(strlen(data)+1);
        strcpy(*addr,data);


        /* Construct the server address structure */
        memset(&saddr, 0, sizeof(saddr));    /* Zero out structure */
        saddr.sin_family = AF_INET;                 /* Internet address family */
        saddr.sin_addr.s_addr = inet_addr(*addr);  /* Server IP address */
        saddr.sin_port   = htons(0);     /* Server port */

        he = gethostbyaddr((char*)&saddr.sin_addr,sizeof(saddr.sin_addr),saddr.sin_family);
        if (he == NULL)
        {
#ifdef WINSOCK_EXAMPLE
            printf("gethostbyaddr for %s failed (%d)\n",data,WSAGetLastError());
#else
            sprintf(s,"gethostbyaddr for %s failed",data);
            perror(s);
#endif    
        }
        else
        {
            if (he->h_name == NULL)
            {
                printf("No h_name present for %s.\n",data);
                strcpy(*name,"");
            }
            else
            {
                *name = malloc(strlen(he->h_name)+1);
                strcpy(*name,he->h_name);
            }

        }
    }
    else
    {
        *name = malloc(strlen(data)+1);
        strcpy(*name,data);

        he = gethostbyname(data);
        if (he == NULL)
        {
#ifdef WINSOCK_EXAMPLE
            printf("gethostbyname for %s failed (%d)\n",data,WSAGetLastError());
#else
            sprintf(s,"gethostbyname for %s failed",data);
            perror(s);
#endif    
            return NULL;
        }

        if (he->h_addr_list == NULL)
        {
            printf("No h_addr_list present for %s.\n",data);
            return NULL;
        }

        *addr = malloc(21);

        strcpy(*addr,inet_ntoa(*((struct in_addr*)he->h_addr)));

    }

    return *addr;
}


/****************************************************************/
/* ResolveService                                               */
/*    Given a service name or port number, resolve it so that   */
/*          we end up with both a service name and a port       */
/*          number.                                             */
/*                                                              */
/*    Parameters:                                               */
/*          data -- string containing the input data.           */
/*          service -- pointer to a string that the function    */
/*                  will create and fill with the service name. */
/*          protocol -- string containing the protocol, tcp     */
/*                  or udp.  Needed in the library calls.       */
/*    Returns:                                                  */
/*          port number.  0 if resolution failed.               */
/*                                                              */
/*    CAVEAT:                                                   */
/*          Dynamically allocates memory for both the service   */
/*              name string, so it's up to the calling function */
/*              to free that memory up when it's done with it.  */
/****************************************************************/
unsigned short ResolveService(char *data, char **service, char *protocol)
{
    struct servent *serv;        /* Structure containing service information */
    unsigned short port;         /* Port to return */
#ifndef WINSOCK_EXAMPLE
    char   s[80];
#endif

    if ((port = atoi(data)) == 0)  /* Is port numeric?  */
    {
        /* Not numeric.  Try to find as name */
        *service = malloc(strlen(data)+1);
        strcpy(*service,data);
        if ((serv = getservbyname(*service, protocol)) == NULL)
        {
#ifdef WINSOCK_EXAMPLE
            printf("getservbyname for %s failed (%d)\n",*service,WSAGetLastError());
#else
            sprintf(s,"getservbyname for %s failed",*service);
            perror(s);
#endif    
            return 0;
        }
        else
            port = ntohs(serv->s_port); /* Found port (network byte order) by name */
    }
    else  /* Numeric. */
    {
        if ((serv = getservbyport(htons(port), protocol)) == NULL)
        {
#ifdef WINSOCK_EXAMPLE
            printf("getservbyport for %s failed (%d)\n",data,WSAGetLastError());
#else
            sprintf(s,"getservbyport for %s failed",data);
            perror(s);
#endif    
            *service = NULL;
        }
        else
        {
            *service = malloc(strlen(serv->s_name)+1);

            strcpy(*service,serv->s_name);
        }
    }

    return port;
}



/**************************************************************************/
/* ReportError                                                            */
/*    Displays a message that reports the error                           */
/*    Encapsulates the difference between UNIX and Winsock error handling */
/* Winsock Note:                                                          */
/*    WSAGetLastError() only returns the error code number without        */
/*    explaining what it means.  A list of the Winsock error codes        */
/*    is available from various sources, including Microsoft's            */
/*    on-line developer's network library at                              */
/*  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winsock/winsock/windows_sockets_error_codes_2.asp */
/**************************************************************************/
void ReportError(char *errorMessage)
{
#ifdef WINSOCK_EXAMPLE
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
#else
    perror(errorMessage);
#endif    
}

/********************************************************/
/* DieWithError                                         */
/*    Separate function for handling errors             */
/*    Reports an error and then terminates the program  */
/********************************************************/
void DieWithError(char *errorMessage)
{
    ReportError(errorMessage);
    exit(1);
}


/**************************************************************/
/*  Support Functions                                         */
/**************************************************************/

/**************************************************************/
/* Global variables for command-line parsing and processing.  */
/**************************************************************/
char DefaultPort[] = "37";
char *Server = NULL;
char *Port = NULL;


/****************************************************************/
/* ParseCommandLine                                             */
/*    Parse the argv list to extract the arguments and options. */
/*    If any errors are found, return to main with FALSE.       */
/*                                                              */
/*  Returns:                                                    */
/*      TRUE -- no errors found                                 */
/*      FALSE -- error found                                    */
/****************************************************************/
BOOL ParseCommandLine(int argc, char *argv[])
{
    int i;
    int varc = 0;
    char *cp;
    BOOL next = FALSE;
    
    for (i=1; i<argc; i++)
    {
        if (argv[i][0] == '-' || argv[i][0] == '/')
        {
            next = FALSE;
            for (cp = &argv[i][1]; next == FALSE && cp != '\0'; cp++)
            {
                switch (tolower(*cp))
                {
                    case 'h':
                        DisplayManPage();
                        exit(0);
                        break;
                    case 'b':
                        m_bBroadcastClient = TRUE;
                        /* if no space between option and var */
                        if (*(cp+1) != '\0')
                        {
                            strcpy(Port, (cp+1));
                            next = TRUE;
                        }
                        else
                        {
                            /* if there's no more argv's */
                            if ((i+1) >= argc)
                            {
                                Port = (char*)DefaultPort;
                            }
                            /* if no option value was given */
                            else if (argv[i+1][0] == '-' || argv[i+1][0] == '/')
                            {
                                Port = DefaultPort;
                            }
                            /* alles in Ordnung */    
                            else
                            {
                                i++;
                                Port = argv[i];
                            }
                            next = TRUE;
                        }
                        printf("-b port %s\n",Port);
                        break;
                    default:
                        return FALSE;
                }  /* end switch */
            } /* end for cp */
        } /* end for argv */
        else
        {
            switch (varc)
            {
                case 0:
                    Server = argv[i];
                    break;
                case 1:
                    Port = argv[i];
                    break;
                default:
                    printf("varc = %d, server [%s], port [%s]\n",varc, Server, Port);
                    return FALSE;
            }
            varc++;
        }
    }  /* end for i */
    return TRUE;
}
    

/*********************************************************************/
/* ResolveArguments                                                  */
/*      Use functions that encapsulate DNS to:                       */
/*          Translate host names to IP addresses and vice versa.     */
/*          Translate service names to port numbers and vice versa.  */
/*                                                                   */
/*  Returns:                                                         */
/*      TRUE -- no errors found                                      */
/*      FALSE -- error found                                         */
/*********************************************************************/
BOOL ResolveArguments(void)
{    
    /* now make sense of it all */

    if (m_bBroadcastClient == TRUE)
    {
        if ((m_port = ResolveService(Port,&m_service,"udp")) == 0)
            return FALSE;
    }
    else
    {
        if (Server == NULL)
        {
            fprintf(stderr,GetUsageMessage());
            exit(1);
        }

        if (ResolveHostAddress(Server,&m_IPaddr,&m_hostname) == NULL)
            return FALSE;

        if (Port == NULL)
        {
            if ((m_port = ResolveService(DefaultPort,&m_service,"udp")) == 0)
                return FALSE;
        }
        else
        {
            if ((m_port = ResolveService(Port,&m_service,"udp")) == 0)
                return FALSE;
        }
    }
    
    return TRUE;
}


/*********************************************************/
/* GetUsageMessage                                       */
/*    In response to an error in invoking the program,   */
/*        produces the command syntax for display with   */ 
/*        an error message.                              */
/*********************************************************/
const char Usage[] = "Usage: udptimec [-h] {-b [<Port>] | <Server> [<Port>]}\n";

const char *GetUsageMessage(void)
{
    return Usage;
}


/************************************************************/
/* DisplayManPage                                           */
/*    In response to the help option (-h), displays the     */
/*        ManPage string array which describes the program  */
/*        and how to use it.                                */
/************************************************************/
const char ManPage[][75] = 
    {
        "\nDisplays source of response message and number of bytes.\n",
        "Displays data in hex-dump format.\n",
        "Interprets and displays time messages (port 37).\n",
        "Interprets and displays all the fields of an NTP message.\n",
        "Accepts either IP address or domain name of server.\n",
        "Accepts either port number or service name (ie, time, timserver, ntp).\n",
        "If not specified, port defaults to time (37).\n",
        "For time and ntp, receives a single response and terminates.\n",
        "As a broadcast client continues running and displaying time\n",
        "    broadcasts; press ESC key to exit.\n",
        "\nOptions:\n",
        " -h  help -- this screen.\n",
        " -b  broadcast client.\n",
        ""
    };

void DisplayManPage(void)
{
    int i;

    fprintf(stdout,GetUsageMessage());
    for (i=0; ManPage[i][0] != '\0'; i++)
        fprintf(stdout,ManPage[i]);
}


/************************************************************/
/* WriteHexLine                                             */
/*    Displays one line (16 bytes) of data as a hex dump.   */
/*    Called by the HexDump function.                       */
/*    Parameters:                                           */
/*          nBytes -- number of bytes in this line (16 max) */
/*          a -- block of data to be dumped                 */
/************************************************************/
void WriteHexLine(int nBytes, unsigned char a[])
{
#define S 71            /* length of one line */
#define ASCII_START 51  /* starting position of the ASCII interpretation */
    char s[S+1];        /* string to be displayed */
    char *hp;           /* pointer to hex portion of the display */
    char *ap;           /* pointer to ASCII portion of the display */ 
    unsigned char   ch;
    int    i, x;

    /* initialize the string to all blanks */
    for (i=0; i<S; i++)
        s[i] = ' ';
    s[S] = '\0';

    hp = s;
    ap = &(s[ASCII_START]);

    /* for each byte */
    for (i=0; i<nBytes; i++)
    {
        ch = (unsigned char)a[i];
        
        /* read the upper nybble of the byte and write its ASCII code */
        x = ch / 16;
        if (x < 10)
            *hp++ = x + '0';
        else 
            *hp++ = (x-10) + 'A';

        /* read the lower nybble of the byte and write its ASCII code */
        x = ch & 0x000F;
        if (x < 10)
            *hp++ = x + '0';
        else 
            *hp++ = (x-10) + 'A';
            
        /* skip to the next byte position      */
        /*   (ie leave a blank between bytes ) */            
        hp++;
        
        /* If it's a printable character, write it to the ASCII section */
        if ( (ch > 31) && (ch < 127) )
            *ap++ = ch;
        /* else write a period instead to mark its place */
        else
            *ap++ = '.';
    }

    printf("%s\n",s);
}


/**************************************************************/
/* HexDump                                                    */
/*    Controls the printing of the entire hex dump.           */
/*    Calls WriteHexLine to actually display a hex-dump line. */
/*    Parameters:                                             */
/*          buffer -- block of data to be dumped              */
/*          len -- number of bytes of data                    */
/**************************************************************/
void HexDump(unsigned char *buffer,int len)
{
    int  i, n, u;
    unsigned char *cp;

    cp = buffer;   /* char pointer for iterating through the buffer */
    n = len / 16;  /* number of complete lines */
    u = len % 16;  /* size of last, incomplete line */
    
    /* Dump all the complete lines */
    for (i = 0; i < n; i++)
    {
        WriteHexLine(16, cp);
        cp += 16;
    }

    /* If there are any bytes left (ie, if there's an incomplete line) */
    /*      then dump it.                                              */
    if (u)
        WriteHexLine(u,cp);

    printf(" **********\n");
}


/*****************************************************************/
/* TestForQuit                                                   */
/*    Tests for the ESC key (ASCII code 27) having been pressed. */
/*    Returns TRUE if the ESC key has been pressed               */
/*          FALSE if a different key or no key has been pressed. */
/*                                                               */
/*    Uses the conio library, because reading the keyboard       */
/*          normally blocks -- ie, all processing stops until    */
/*          user has typed in a complete line and pressed ENTER. */
/*    conio's _kbhit() function allows the program to test       */
/*          whether a key has been pressed before it attempts to */
/*          read it.  This prevents blocking.                    */
/*    conio is not supported by UNIX/Linux, so to port this      */
/*          program to UNIX/Linux you will need to:              */
/*      1. This function need to be removed, or                  */
/*      2. A Linux port of conio would need to be used, or       */
/*      3. This code would need to be replaced by functionally   */
/*              equivalent terminal-handling code.               */
/*****************************************************************/
BOOL TestForQuit(void)
{
    /* if "keyboard hit"; ie, a key has been pressed */
    if (_kbhit())
    {
        if (_getch() == '\x1B')  /* ESC */
            return TRUE;
        else
            return FALSE;
    }
    /* else allow program to continue on uninterrupted */
    else
        return FALSE;
}


/***************************/
/*   *****   END   *****   */
/***************************/
