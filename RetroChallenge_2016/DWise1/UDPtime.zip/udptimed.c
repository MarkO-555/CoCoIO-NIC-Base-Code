/*************************************************************************/
/* udptimed.c                                                            */
/* David C. Wise, 2008                                                   */
/* Email: dwise1@aol.com                                                 */
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* Simple UDP Time Server Example                                        */
/* Acts as a UDP server for the Time Protocol (UDP port 37, RFC 868).    */
/* Operates either as a regular server or as a broadcast server.         */
/* As a regular server:                                                  */
/*      Receives a request from a client.                                */
/*      Gets the system time, converts it to protocol time, generates    */
/*          a time message, and sends it to the requesting client.       */ 
/* As a broadcast server:                                                */
/*      Once every three seconds, gets the system time, converts it to   */
/*          protocol time, generates a time message, and broadcasts it.  */
/*                                                                       */
/* NOTE:                                                                 */
/*      Time in the time protocols are expressed as number of seconds    */
/*          since midnight, 1900 January 01.                             */
/*      However, C's time functions are based on UNIX time, which is     */
/*          the number of seconds since midnight, 1970 January 01.       */
/*      This requires us to convert our system time from UNIX time to    */
/*          protocol time before we can send it.                         */
/*      RFC 868 gives the time at midnight, 1970 January 01, as being    */
/*          2,208,988,800, so that is our conversion offset.             */
/*                                                                       */
/* Written to support the Time Protocol features of:                     */
/*      udptimec -- UDP time client                                      */
/*************************************************************************/
/* Usage: udptimed {-b <Broadcast IP Address> [<Port>] | [<Port>]}       */
/*                                                                       */
/*      Unlike udptimec, does not have any DNS functionality.            */
/*      Requires that the port be entered as a number.                   */
/*      If not specified, port defaults to 37 (time).                    */
/*      Requires that the broadcast address be entered as a              */
/*          dotted-decimal IP address.                                   */
/*      Runs in an infinite loop.  The only way to exit the program is   */
/*          to cancel itself (eg, Ctrl-C).                               */
/*      Options:                                                         */
/*          -b  broadcast server.                                        */
/*************************************************************************/
/* Actual sockets programming based on code examples from                */
/*      "The Pocket Guide to TCP/IP Sockets: C Version"                  */
/*                 by Michael J. Donahoo and Kenneth L. Calvert:         */
/*                                                                       */
/* The book's  original UNIX source code is freely available from        */
/*      their web site at                                                */
/*          http://cs.baylor.edu/~donahoo/PocketSocket/textcode.html     */
/*      and the Winsock version of the code at                           */
/*          http://cs.baylor.edu/~donahoo/PocketSocket/winsock.html      */
/*                                                                       */
/* Please read the authors' disclaimer on their web site at              */
/*    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html */
/* In particular note that "the authors and the Publisher DISCLAIM ALL   */
/*      EXPRESS AND IMPLIED WARRANTIES, including warranties of          */
/*      merchantability and fitness for any particular purpose.          */
/* Your use or reliance upon any sample code or other information in     */
/*      [their] book will be at your own risk.                           */
/* No one should use any sample code (or illustrations) from [their]     */
/*      book in any software application without first obtaining         */
/*      competent legal advice."                                         */
/*************************************************************************/
/* This program will compile under Windows or UNIX/Linux depending on    */
/*      the setting of the WINSOCK_EXAMPLE define                        */
/* The Winsock version will require the Winsock library to be linked in  */
/*      (exact method and library name are compiler-dependent;           */ 
/*       name is usually some form of winsock.lib or ws2_32.lib)         */
/*************************************************************************/

/* #define for Windows; #undef for UNIX/Linux */
#define WINSOCK_EXAMPLE

#include <stdlib.h>     /* for atoi()                 */
#include <stdio.h>      /* for printf() and fprintf() */
#include <string.h>     /* for memset()               */
#include <time.h>       /* for time functions         */
#ifdef WINSOCK_EXAMPLE
#include <winsock2.h>   /* for socket(),...           */
#else
#include <unistd.h>     /* for close()                */
#include <sys/socket.h> /* for socket(),...           */
#include <netinet/in.h> /* for socket(),...           */
#include <arpa/inet.h>  /* for inet_addr()            */
#endif    



#define BUFFERMAX 255     /* Longest string to echo */
#define DEFAULT_PORT  37

#ifndef WINSOCK_EXAMPLE
typedef int SOCKET;
#endif

const char sUsage[] = "Usage: udptimed {-b <Broadcast IP Address> [<Port>] | [<Port>]}\n";

void RunServer(SOCKET sock, struct sockaddr_in *serverAddr);
void RunBroadcastServer(SOCKET sock, struct sockaddr_in *serverAddr);
void DieWithError(char *errorMessage);  /* External error handling function */
unsigned long GetTime(char *sTime);
void HexDump(unsigned char *buffer,int len);


/*******************************************************************/
/* main                                                            */
/*    Like opinions, every program has one.                        */
/*                                                                 */
/*    Parses and verifies the command-line arguments,              */
/*          exiting if erroneous.                                  */
/*    Loads and starts up the Winsock DLL (Winsock only).          */
/*    Creates the UDP socket.                                      */
/*    Loads the sockaddr_in struct with the port and address data. */
/*    Passes the socket and the sockaddr_in struct to either       */
/*          server function, depending on whether the broadcast    */
/*          option was entered.                                    */
/*    NOTE:                                                        */
/*      The server functions both run in an infinite loop, so      */
/*          control never returns from them back to main.          */
/*      The only way to exit the program is to cancel it (Ctrl-C). */
/*******************************************************************/
int main(int argc, char *argv[])
{
    SOCKET sock;                      /* Socket */
    struct sockaddr_in serverAddr;    /* Server address */
    unsigned short serverPort;        /* Server port */
#ifdef WINSOCK_EXAMPLE
    WORD wVersionRequested;           /* Version of Winsock to load */
    WSADATA wsaData;                  /* Winsock implementation details */ 
#endif
    int     bBroadcast = 0;           /* broadcast option flag */
    unsigned long  ulAddr;            /* 32-bit address value  */

    /* Parse and validate the command line arguments      */
    /* NOTE:  the method employed here is not the most elegant, 
            but rather is just ad-hoc, make-do, and not bullet-proof. */
            
    /* if no arguments, then is a regular server using the default port */        
    if (argc == 1)
    {
        ulAddr = INADDR_ANY;        /* already in network byte order */
        serverPort = DEFAULT_PORT;
    }
    /* if the broadcast option is chosen */
    else if (!strcmp(argv[1],"-b"))
    {
        bBroadcast = 1;
        
        /* broadcast option requires at least one more argument, 
                but not more than two more */
        /* if those conditions not met, exit with usage message. */
        if (argc == 2 || argc > 4)
        {
            fprintf(stderr,sUsage);
            exit(1);
        }
        else  /* got right number of arguments */
        {
            /* assume argument is dotted-decimal broadcast address */
            /* convert it to 32-bit value in network byte order    */
            /* validate it later by trying to use it and have it fail */
            ulAddr = inet_addr(argv[2]);
            
            /* if there's a second additional argument, then assume 
                    it's the port number.  Else use the default port number. */
            if (argc == 4)
                serverPort = atoi(argv[1]);   
            else
                serverPort = DEFAULT_PORT;
        }
    }
    else  /* is maybe a regular time server with a specified port */
    {
        /* if too many more arguments, exit with usage message */
        if (argc > 2)
        {
            fprintf(stderr,sUsage);
            exit(1);
        }
        /* else get the port number */
        else 
        {
            ulAddr = INADDR_ANY;        /* already in network byte order */
            serverPort = atoi(argv[1]);   
        }
    }
    
    /* The command line has no obvious flaws and values have been assigned 
        to ulAddr and serverPort */

#ifdef WINSOCK_EXAMPLE
    /* Winsock requires explicit DLL and library initialization  */
    /* If Winsock startup fails, exit with an error message.     */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }
#endif

    /* Create socket for sending datagrams */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("socket() failed");

    /* Construct address structure */
    memset(&serverAddr, 0, sizeof(serverAddr));   /* Zero out structure */
    serverAddr.sin_family = AF_INET;              /* Internet address family */
    serverAddr.sin_addr.s_addr = ulAddr;          /* byte order already 
                                                        taken care of */
    serverAddr.sin_port = htons(serverPort);      /* port */

    /* call the appropriate server function, depending on the broadcast flag */
    /* NOTE:  since both run infinite loops, control will never return to here */
    if (bBroadcast)
        RunBroadcastServer(sock, &serverAddr);
    else
        RunServer(sock, &serverAddr);
        
    /* NOT REACHED */

#ifdef WINSOCK_EXAMPLE
    /* Winsock requires explicit unloading of the DLL  */
    /* Just added for completeness, since this code will never be reached */
    WSACleanup();  /* Cleanup Winsock */
#endif

    return 0;        
}


/************************************************************/
/* RunServer                                                */
/*    Runs the regular server session.                      */
/*    Enters an infinite loop in which it waits for a       */
/*          client request, whereupon it gets the system    */
/*          time, formats it into a time message, and       */
/*          sends that message to the client.               */
/*    NOTE:                                                 */
/*      The protocol calls for the message format to be a   */
/*          32-bit integer value in network byte order.     */
/*          The call to GetTime fetches a 32-bit value and  */
/*          htonl() places it in network byte order.        */
/*      This function enters into an infinite loop.  The    */
/*          only way to exit the loop is to cancel the      */
/*          the program itself (Ctrl-C).                    */
/************************************************************/
void RunServer(SOCKET sock, struct sockaddr_in *serverAddr)
{
    char sendString[6];               /* String to broadcast */
    unsigned int sendStringLen;       /* Length of string to broadcast */
    unsigned char buffer[BUFFERMAX];  /* Buffer for echo string */
    int respStringLen;                /* Length of response string */
    struct sockaddr_in fromAddr;      /* Source address of echo */
    int   fromSize;
    char  sTime[40];

    /* Bind to the broadcast port */
    if (bind(sock, (struct sockaddr *) serverAddr, sizeof(*serverAddr)) < 0)
        DieWithError("bind() failed");

    printf("Starting timserver on port %d\n",ntohs(serverAddr->sin_port));
    
    for (;;) /* Run forever */
    {
		/* Receive a single datagram from the server */
	    fromSize = sizeof(fromAddr);
		if ((respStringLen = recvfrom(sock, (char *)buffer, BUFFERMAX, 0, 
					(struct sockaddr *) &fromAddr, (int *)&fromSize)) < 0)
			DieWithError("recvfrom() failed");

		*((unsigned long*)(&sendString[0])) = htonl(GetTime(sTime));
		sendStringLen = 4;

         if (sendto(sock, sendString, sendStringLen, 0, 
			  (struct sockaddr *)&fromAddr, fromSize) != sendStringLen)
             DieWithError("sendto() sent a different number of bytes than expected");

        printf("Serviced request from %s at %s\n",inet_ntoa(fromAddr.sin_addr),sTime);
        if (respStringLen)
            HexDump(buffer,respStringLen);
    }
        
    /* NOT REACHED */

}


/************************************************************/
/* RunBroadcastServer                                       */
/*    Runs the broadcast session.                           */
/*    Changes the socket to a broadcast socket and then     */
/*          broadcasts the time once every three seconds.   */
/*    NOTE:                                                 */
/*      The protocol calls for the message format to be a   */
/*          32-bit integer value in network byte order.     */
/*          The call to GetTime fetches a 32-bit value and  */
/*          htonl() places it in network byte order.        */
/*      This function enters into an infinite loop.  The    */
/*          only way to exit the loop is to cancel the      */
/*          the program itself (Ctrl-C).                    */
/************************************************************/
void RunBroadcastServer(SOCKET sock, struct sockaddr_in *broadcastAddr)
{
    unsigned int sendStringLen;       /* Length of string to broadcast */
    unsigned char sendBuffer[6];        /* Buffer for data to broadcast */
    int broadcastPermission;          /* Socket opt to set permission to broadcast */
    char  sTime[40];

    /* Set socket to allow broadcast */
    broadcastPermission = 1;
    if (setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (void *) &broadcastPermission, 
          sizeof(broadcastPermission)) < 0)
        DieWithError("setsockopt() failed");

    for (;;) /* Run forever */
    {
		/* create time data */
		*((unsigned long*)(&sendBuffer[0])) = htonl(GetTime(sTime));
		sendStringLen = 4;

		/* Broadcast sendString in datagram to clients every 3 seconds*/
         if (sendto(sock, sendBuffer, sendStringLen, 0, 
                (struct sockaddr *)broadcastAddr, sizeof(struct sockaddr))
                            != sendStringLen)
             DieWithError("sendto() sent a different number of bytes than expected");

        /* Sleep for 3 seconds to avoid flooding the network */
#ifdef WINSOCK_EXAMPLE
        _sleep(3000);   /* Windows sleep is in milliseconds */
#else
        sleep(3);       /* Linux sleep is in seconds */
#endif    
    }
        
    /* NOT REACHED */

}


/**************************************************************************/
/* DieWithError                                                           */
/*    Displays a message that reports the error and then terminates       */
/*        the program.                                                    */
/*    Encapsulates the difference between UNIX and Winsock error handling */
/* Winsock Note:                                                          */
/*    WSAGetLastError() only returns the error code number without        */
/*    explaining what it means.  A list of the Winsock error codes        */
/*    is available from various sources, including Microsoft's            */
/*    on-line developer's network library at                              */
/*  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winsock/winsock/windows_sockets_error_codes_2.asp */
/**************************************************************************/
void DieWithError(char *errorMessage)
{
#ifdef WINSOCK_EXAMPLE
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
#else
    perror(errorMessage);
#endif    
    exit(1);
}


/************************************************************/
/* GetTime                                                  */
/*    Gets the system time and returns it converted to      */
/*          the protocol's time base.  Also generates an    */
/*          ASCII date-time string for display.             */
/*    NOTE:                                                 */
/*      Time in the time protocols are expressed as number  */
/*          of seconds since midnight, 1900 January 01.     */
/*          However, C's time functions are based on UNIX   */
/*          time, which is the number of seconds since      */
/*          midnight, 1970 Jan 01.  So when we get our      */
/*          system time, we need to convert it to the time  */
/*          protocol's time before we can send it.          */
/*      The time protocol RFC, RFC 868, gives the time at   */
/*          1970 Jan 01 as being 2,208,988,800, so that is  */
/*          our conversion offset.                          */
/*                                                          */
/*      BTW, MS-DOS time was based on 1980 Jan 01, around   */
/*          when the first IBM PC's came out.               */
/************************************************************/
#define TIME_OFFSET_1970  2208988800UL

unsigned long GetTime(char *sTime)
{
	time_t  Time;
    struct tm* t;

	time(&Time);
    t = localtime(&Time);
    strcpy(sTime,asctime(t));
	return (unsigned long)Time + TIME_OFFSET_1970;	
}


/************************************************************/
/* WriteHexLine                                             */
/*    Displays one line (16 bytes) of data as a hex dump.   */
/*    Called by the HexDump function.                       */
/*    Parameters:                                           */
/*          nBytes -- number of bytes in this line (16 max) */
/*          a -- block of data to be dumped                 */
/************************************************************/
void WriteHexLine(int nBytes, unsigned char a[])
{
#define S 71            /* length of one line */
#define ASCII_START 51  /* starting position of the ASCII interpretation */
    char s[S+1];        /* string to be displayed */
    char *hp;           /* pointer to hex portion of the display */
    char *ap;           /* pointer to ASCII portion of the display */ 
    unsigned char   ch;
    int    i, x;

    /* initialize the string to all blanks */
    for (i=0; i<S; i++)
        s[i] = ' ';
    s[S] = '\0';

    hp = s;
    ap = &(s[ASCII_START]);

    /* for each byte */
    for (i=0; i<nBytes; i++)
    {
        ch = (unsigned char)a[i];
        
        /* read the upper nybble of the byte and write its ASCII code */
        x = ch / 16;
        if (x < 10)
            *hp++ = x + '0';
        else 
            *hp++ = (x-10) + 'A';

        /* read the lower nybble of the byte and write its ASCII code */
        x = ch & 0x000F;
        if (x < 10)
            *hp++ = x + '0';
        else 
            *hp++ = (x-10) + 'A';
            
        /* skip to the next byte position      */
        /*   (ie leave a blank between bytes ) */            
        hp++;
        
        /* If it's a printable character, write it to the ASCII section */
        if ( (ch > 31) && (ch < 127) )
            *ap++ = ch;
        /* else write a period instead to mark its place */
        else
            *ap++ = '.';
    }

    printf("%s\n",s);
}


/**************************************************************/
/* HexDump                                                    */
/*    Controls the printing of the entire hex dump.           */
/*    Calls WriteHexLine to actually display a hex-dump line. */
/*    Parameters:                                             */
/*          buffer -- block of data to be dumped              */
/*          len -- number of bytes of data                    */
/**************************************************************/
void HexDump(unsigned char *buffer,int len)
{
    int  i, n, u;
    unsigned char *cp;

    cp = buffer;   /* char pointer for iterating through the buffer */
    n = len / 16;  /* number of complete lines */
    u = len % 16;  /* size of last, incomplete line */
    
    /* Dump all the complete lines */
    for (i = 0; i < n; i++)
    {
        WriteHexLine(16, cp);
        cp += 16;
    }

    /* If there are any bytes left (ie, if there's an incomplete line) */
    /*      then dump it.                                              */
    if (u)
        WriteHexLine(u,cp);

    printf(" **********\n");
}
