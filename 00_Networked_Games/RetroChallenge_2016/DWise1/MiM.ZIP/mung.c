
/*************************************************************************/
/* mung.c                                                                */
/* David C. Wise, 2008                                                   */
/* Email: dwise1@aol.com                                                 */
/*************************************************************************/
/* This program is intended for training purposes only.  It is not nor   */
/*      was it ever intended for commercial or production use.           */
/* I disclaim any and all responsibility should you decide to use it.    */
/*************************************************************************/
/* MiM Capture File Conversion Utility                                   */
/*   Opens a capture file created by MiM, which contains binary data,    */
/*      and converts it to a printable format.                           */
/*                                                                       */
/*   This utility was written quick-and-dirty and it shows.              */
/*   But it got the job done.                                            */
/*************************************************************************/
/* Usage: mung <input file>                                              */
/*      input file is a MiM capture file                                 */
/*      Output is to stdout, but it can be redirected to a disk file.    */
/*                                                                       */
/* Basic Sequence of Operations:                                         */
/*      1. Open the capture file for input.                              */
/*      2. Read in a block at a time and processing one character at     */
/*            a time:                                                    */
/*         a. Print a printable character as-is.                         */
/*         b. Print a non-printable character's ASCII code as a          */
/*              back-slash followed by the ASCII code in decimal.        */
/*         c. Print a newline as a newline ("\n").  This requires        */
/*              deferring the processing of a possible CR                */
/*              (ASCII code 13) until we process the next character so   */
/*              that we can see whether it's a LF (ASCII code 10).       */
/*      3. After processing the last character, close the file.          */
/*************************************************************************/

#include <stdlib.h>
#include <stdio.h>

#define BUFSIZE 1024

int main(int argc, char *argv[])
{
    char sFileName[40];
    FILE *fp;
    unsigned char buffer[BUFSIZE];
    unsigned char *cp;
    int  iBytesRead;
    int  flag = 0;
    int  i;
    
    /* Test for correct number of arguments */
    if (argc < 2 || argc > 4)     
    {
        fprintf(stderr, "Usage:  mung <input file>\n");
        exit(1);
    }

    /* read filename */
    strcpy(sFileName,argv[1]);    
    
    /* open the file or die trying */
    if ( (fp = fopen(sFileName,"rb")) == NULL)
    {
        perror("file open");
        exit(1);
    }
    else
        printf("Opened file: %s\n",sFileName);
    
    /* read in 1K bytes at a time until we run out of data          */
    /* loop through one character at a time:                        */    
    /*     if it's a newline, then go to a new line                 */
    /*     if it's a printable character, then print it             */
    /*     else it's unprintable, so print out its ASCII code value */
    
    /* read next block of data and loop as long as we've read something */
    while( (iBytesRead = fread(buffer,1,BUFSIZE,fp)) > 0)
    {
        /* start processing at the beginning of the buffer */
        cp = buffer;
        
        /* process one character at a time */
        for (i=0; i<iBytesRead; i++, cp++)
        {
            /* In Windows/DOS, the newline is CRLF or "\x0d\x0a"          */
            /* flag is used to detect the CR character and to distinguish */
            /*      it from a binary value of 13                          */
            /* flag is set when we detect a 13, but we also do not print  */
            /*      it yet, instead deferring processing it until we know */
            /*      what the next character is.                           */
            /*          if next character is 10, then print "\n"          */
            /*          else print the deferred "\\13" and process the    */
            /*              character that followed it.                   */
            /* Note that if the next character is also 13, then we need   */
            /*      to defer its processing too, based on its next        */
            /*      character.                                            */ 
            
            /* if we have a deferred 13 pending processing */
            if (flag)
            {
                flag = 0;
                
                /* if next character is 10, then it's a CRLF   */
                if (*cp == 10)
                {
                    printf("\n");
                }
                else
                /* it's not a CRLF, so print the 13 and process next char */
                {
                    /*  print the deferred 13 */
                    printf("\\13 ");
                    
                    /* if next char is 13, defer its processing */
                    if (*cp == 13)
                    {
                        flag = 1;
                    }
                    
                    /* else print the next character */
                    else
                    {
                        /* if it's a printable character, simply print it */
                        if (*cp >= 32 && *cp < 127)
                        {
                            printf("%c",*cp);
                        }
                        /* else print its ASCII code in decimal */
                        else
                        {
                            printf("\\%d ",*cp);
                        }
                    }
                }
            }
            
            /* else conduct normal processing */
            else
            {
                /* if it's a printable character, simply print it */
                if (*cp >= 32 && *cp < 127)
                {
                    printf("%c",*cp);
                }
                /* else defer the processing of a 13 */
                else if (*cp == 13)
                {
                    flag = 1;
                }
                /* else print its ASCII code in decimal */
                else
                {
                    printf("\\%d ",*cp);
                }
            }
        }
    }
    
    /* close the input file and exit the program */
    fclose(fp);
    
    return 0;
}

