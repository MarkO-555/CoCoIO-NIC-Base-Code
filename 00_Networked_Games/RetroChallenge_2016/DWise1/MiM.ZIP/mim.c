/****************************************************************************/
/* MiM.c  ("Man-in-the-Middle")                                             */
/* David C. Wise, 2008                                                      */
/* Originally written circa 2001                                            */
/* Email: dwise1@aol.com                                                    */
/*                                                                          */
/* This program is intended for training and educational purposes only.     */
/* It is not nor was it ever intended for commercial or production use.     */
/* I disclaim any and all responsibility should you decide to use it.       */
/****************************************************************************/
/*  The name is taken from the cyber attack in which the attacker places    */
/*  itself between two victims and impersonates them, capturing their data  */
/*  packets while passing them on.  However, instead of being an attempt    */
/*  to implement that attack, MiM was written as a research tool in order   */
/*  to investigate the negotiation sequence between a telnet client and     */
/*  server.                                                                 */
/*                                                                          */
/*  MiM appears to the client as the server and to the server as a client.  */
/*  The client connects to MiM and MiM in turn connects to the server.      */
/*  Then whenever MiM receives a packet from either the client or the       */
/*  server, it sends it to the other peer and labels and writes the packet  */
/*  contents to a capture file.                                             */
/*                                                                          */
/*  In the case of the telnet protocol, that capture file contains ASCII    */
/*  data mixed with binary data, which makes it unreadable in a text        */
/*  editor.  In order to make the capture file human-readable, I also wrote */
/*  a simple filter utility, MUNG, that translates unprintable ASCII codes  */
/*  to their decimal value.                                                 */
/*                                                                          */
/*  I wrote MiM as my first real sockets application and before I acquired  */
/*  a packet sniffer.  I also did not discover until years later that I had */
/*  reinvented the proxy server.                                            */
/*                                                                          */
/*  Also, since it was my first sockets application, it is more primitive   */
/*  and does not necessarily employ good sockets programming practices.     */
/*  For example, instead of supporting a graceful TCP shutdown as should be */
/*  done, it simply slams the connection shut, which is rude behavior that  */
/*  causes problems for the peers.                                          */
/****************************************************************************/
/*  In order to simplify the parsing of the command line arguments, MiM     */
/*  expects all options to precede the arguments.  It also expects all      */
/*  options to be separate (ie, "-u -f" instead of "-uf") and it expects    */
/*  there to be a space between the -f and the capture file name.           */
/*                                                                          */
/*  The command-line syntax is (on one line):                               */
/*      MiM  [-u] [-t] [-f <capture file>] <listen-port> <server addr>      */
/*              [<server port>]                                             */
/*    Arguments:                                                            */
/*      <listen-port> -- is the port that the client will connect to MiM    */
/*              with.  It may be either a number or a well-known service    */
/*              name.                                                       */
/*              This argument is required.                                  */
/*      <server addr> -- is the address of the server that MiM will connect */
/*              with.  It may be either a host name or a dotted-decimal     */
/*              IP address.                                                 */
/*              This argument is required.                                  */
/*      <server port> -- is the port on the server that MiM will connect    */
/*              to.  It may be either a number or a well-known service      */
/*              name.                                                       */
/*              This argument is optional.  If it is not given, the default */
/*              value will be the telnet port, 23.                          */
/*    Options:                                                              */
/*      -u  -- tells MiM to run a UDP session.                              */
/*      -t  -- tells MiM to run a TCP session.  This is the default mode,   */
/*              so it is not necessary to specify this option.              */
/*      -f  -- specifies the name of the capture file.                      */
/*              If this option is used, then the file name is required;     */
/*                  failure to provide the file name will result in an      */
/*                  error.                                                  */
/*              If this option is not used, then by default the output will */
/*                  be routed to the console via the standard output file,  */
/*                   stdout, even though that serves no useful purpose.     */
/****************************************************************************/
/*  Unlike my other projects, MiM was written solely as a Winsock           */
/*  application.  Although I had made no attempt to port it to UNIX/Linux,  */
/*  that should be a fairly trivial exercise, which is left to the student. */
/****************************************************************************/

#include <stdlib.h>     /* for exit() */
#include <stdio.h>      /* for printf(), fprintf() */
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <winsock2.h>    /* for socket(),... */


/* ***************  DEFINES  *************** */

#define MAXPENDING    5    /* Maximum outstanding connection requests */
#define TCPRCVBUFSIZE 32   /* Size of receive buffer */
#define UDPRCVBUFSIZE 255  /* Size of receive buffer */
#define TELNETPORT    23   /* default well-known port for telnet */


/* ***************  GLOBAL DATA DECLARATIONS  *************** */

typedef struct
{
    BOOL bTCP;
    BOOL bCapture;
    char *sCaptureFile;
    char *sListenPort;
    char *sServer;
    char *sServerPort;
} Parameters;                      

const char *sUsage = "MiM  [-h] [-u] [-t] [-f <file>] "
                     "<listen-port> <server> [<server port>]";

/* ***************  FUNCTION PROTOTYPES  *************** */
BOOL GetCommandLineParameters(int argc, char *argv[], Parameters  *params);
BOOL ProcessCmdLineParameters(Parameters  *params, 
                              BOOL *bTCP, char *servIP, 
                              unsigned short *ServPort, 
                              unsigned short *ListenPort);
void DisplayManPage(void);

BOOL OpenCaptureFile(char *filename);
void CaptureData(char *title,char *buffer,int count);
void CloseCaptureFile(void);

char *ResolveHostAddress(char *addr,char *name);
unsigned short ResolveService(char *serv_in, char *protocol);

void ProcessTCP(unsigned short ListenPort,char *servIP,unsigned short ServPort);
void ProcessUDP(unsigned short ListenPort,char *servIP,unsigned short ServPort);

void DieWithError(char *errorMessage);  /* Error handling function */
BOOL TestForQuit(void);


/* ***************  CODE  *************** */

/********************************************************************/
/* main -- like opinions, every program has one.                    */
/*                                                                  */
/*  Parse the command-line arguments, verifying that the options    */
/*      are valid and that there are a valid number of arguments.   */
/*  Start up the Winsock DLL.                                       */
/*  Resolve the server and port/service arguments.                  */
/*  Run the session, be it TCP or UDP.                              */
/*  Clean up and exit.                                              */
/********************************************************************/
int main(int argc, char *argv[])
{
    BOOL bTCP;
    unsigned short ListenPort;     /* Echo server port */
    unsigned short ServPort;     /* Echo server port */
    char servIP[40];                    /* Server IP address (dotted quad) */
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */ 

    Parameters  params = {TRUE, FALSE, NULL, NULL, NULL, NULL};
    
    /* Parse the command-line arguments              */
    /* Exit with usage message if there's an error   */
    if (GetCommandLineParameters(argc, argv, &params) == FALSE)
    {
        fprintf(stderr, "Usage:  %s\n", sUsage);
        exit(1);
    }

    /* else, command line parsed OK  */

    /* Need to start up WinSock in order to use name and service resolution */
    /* Exit with error if DLL fails to load successfully                    */
    /* Note that DieWithError won't work until WSAStartup runs successfully, */
    /*      up to and including this point we need to write explicitly      */
    /*      to stderr.                                                      */
    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }

    /* else, Winsock DLL loaded and started up successfully.               */
    /* From this point on, we can use DieWithError.                        */
    /* Though we will continue to write to stderr for non-Winsock errors.  */

    /*  resolve the address and ports and apply the command line arguments */
    if (ProcessCmdLineParameters(&params, &bTCP, servIP, &ServPort, 
            &ListenPort) == FALSE)
    {
        fprintf(stderr, "Failed to resolve address or port\n");
        exit(1);
    }

    /* open and process the session, based on whether it's tcp or udp   */
    /* We don't return from this function call until the session is over */
    if (bTCP == TRUE)
        ProcessTCP(ListenPort,servIP,ServPort);
    else
        ProcessUDP(ListenPort,servIP,ServPort);

    /* Done! */

    /* finish and clean up */
    CloseCaptureFile();
    printf("\n");    /* Print a final linefeed */

    WSACleanup();  /* Cleanup Winsock */

    return 0;
}


/************************************************************/
/* TCP Session Handling Functions                           */
/************************************************************/


/************************************************************/
/* TCP Session Handling Function Prototypes                 */
/************************************************************/
SOCKET CreateTCPListenSocket(unsigned short port);
SOCKET AcceptTCPConnection(SOCKET servSock);
void HandleTCPMsg(SOCKET in_sock,SOCKET out_sock,char *ID);

/***************************************************************************/
/* ProcessTCP                                                              */
/*    Processes the TCP session:                                           */
/*      Listens for and accepts a connection from the client.              */
/*      Connects to the server.                                            */
/*      Loops until the user presses the ESC key:                          */
/*          Using select(), checks either socket for input                 */
/*          When a packet is received, passed to HandleTCPMsg which will   */
/*              send the packet to the other socket as well as writing it  */
/*              to the capture file.                                       */
/*                                                                         */
/*    Parameters:                                                          */
/*          ListenPort -- selected listening port                          */
/*          servIP -- the server's dotted-decimal IP address               */
/*          ServPort -- server's port                                      */
/*    Returns:                                                             */
/*          void                                                           */
/*                                                                         */
/*    CAVEATS:                                                             */
/*          This was my first real sockets application, so the TCP         */
/*              connection here behaves very rudely.                       */
/*          Instead of recognizing and implementing a graceful shutdown    */
/*              of the connection, it just simply slams it shut.           */
/*          More specifically, in HandleTCPMsg() if recv() returns a zero  */
/*              (the indication of a shutdown) then MiM does a             */
/*              DieWithError.                                              */
/*          This function will also only handle one session and will       */
/*              accept only one connection and will terminate at the end   */
/*              of the session.  It would have to be modified to handle    */
/*              multiple clients or to loop and wait for the next client   */
/*              to connect to it.                                          */
/***************************************************************************/
void ProcessTCP(unsigned short ListenPort,char *servIP,unsigned short ServPort)
{
    SOCKET servSock;              /* Socket handle for server */
    SOCKET clntSock;              /* Socket handle for client */
    SOCKET listenSock;            /* Socket handle for listening socket */
    struct sockaddr_in ServAddr;  /* Server address */

    fd_set sockSet;               /* Set of socket handles for select() */
    long timeout = 0L;            /* Timeout seconds value       */
    long timeout_ms = 1000L;      /* Timeout microseconds value  */
    struct timeval selTimeout;    /* Timeout struct for select() */

    printf("Processing TCP Session\n");

    /* create listening socket and wait for a connection */
    listenSock = CreateTCPListenSocket(ListenPort);
    clntSock = AcceptTCPConnection(listenSock);

    /* Create the server socket and connect to the server */
    if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET)
        DieWithError("socket() failed");

    memset(&ServAddr, 0, sizeof(ServAddr));     /* Zero out structure */
    ServAddr.sin_family      = AF_INET;             /* Internet address family */
    ServAddr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
    ServAddr.sin_port        = htons(ServPort); /* Server port */
    
    if (connect(servSock, (struct sockaddr *) &ServAddr, sizeof(ServAddr)) < 0)
        DieWithError("connect() failed");

    /* initialize the timeout value for select()  */
    /* will use these each time through the loop  */
    timeout = 0;
    timeout_ms = 100000;

    /* loop until user presses the ESC key       */
    /* otherwise, MiM will just DieWithError when either */
    /*      server or client shuts down the connection. */
    while (TestForQuit() == FALSE)
    {
        /* Zero socket handle vector and set for server sockets */
        /* This must be reset every time select() is called */
        FD_ZERO(&sockSet);
        FD_SET(servSock, &sockSet);
        FD_SET(clntSock, &sockSet);

        /* Timeout specification */
        /* This must be reset every time select() is called */
        selTimeout.tv_sec = timeout;       /* timeout (secs.) */
        selTimeout.tv_usec = timeout_ms;   /* microseconds */

        /* Suspend program until handle is ready or timeout */
        /* The first parameter to select() is ignored in Winsock */
        /* We are only interested in sockets ready to be read    */
        if (select(0, &sockSet, NULL, NULL, NULL) > 0)
        {
            if (FD_ISSET(servSock, &sockSet))
            {
                /* handle packet received from the server */
                HandleTCPMsg(servSock,clntSock,"Server");
            }

            if (FD_ISSET(clntSock, &sockSet))
            {
                /* handle packet received from the client */
                HandleTCPMsg(clntSock,servSock,"Client");
            }
        }

    } /* end while */
    
    /* shutdown */
    /* will actually never reach here normally, since a shutdown  */
    /*  will cause HandleTCPMsg to DieWithError                   */
    closesocket(servSock);
    closesocket(clntSock);
}


/***************************************************************************/
/* HandleTCPMsg                                                            */
/*    Reads the data packet from the incoming socket and relays it out     */
/*      to the outgoing socket.                                            */
/*    Also writes the data to the capture file.                            */
/*                                                                         */
/*    Parameters:                                                          */
/*          in_sock -- the socket to read the data from                    */
/*          out_sock -- the socket to write the data out to                */
/*          ID -- string identifying the source of the data                */
/*    Returns:                                                             */
/*          void                                                           */
/*                                                                         */
/*    CAVEAT:                                                              */
/*          This was my first real sockets application, so the TCP         */
/*              connection here behaves very rudely.                       */
/*          Instead of recognizing and implementing a graceful shutdown    */
/*              of the connection, it just simply slams it shut.           */
/*          More specifically, in HandleTCPMsg() if recv() returns a zero  */
/*              (the indication of a shutdown) then MiM does a             */
/*              DieWithError.                                              */
/***************************************************************************/
void HandleTCPMsg(SOCKET in_sock,SOCKET out_sock,char *ID)
{
    char title[40];
    char buffer[TCPRCVBUFSIZE];     /* Buffer for packet data */
    int  bytesRcvd;                 /* Bytes read in single recv() */
    char sErrorMsg[100];

    /* Set up label for source of the packet */
    sprintf(title,"%s:",ID);
                                          
    /* Receive up to the buffer size bytes from the sender */
    if ((bytesRcvd = recv(in_sock, buffer, TCPRCVBUFSIZE, 0)) <= 0)
        DieWithError("recv() failed or connection closed prematurely");

    /* write the source label and packet data to the capture file */
    CaptureData(title,buffer,bytesRcvd);

    /* echo message out the other port  */
    if (send(out_sock, buffer, bytesRcvd, 0) != bytesRcvd)
    {
        sprintf(sErrorMsg,"%s send() sent a different number of bytes "
                            "than expected",ID);
        DieWithError(sErrorMsg);
    }
}

     
/***************************************************************************/
/* CreateTCPListenSocket                                                   */
/*    Creates a listening socket, binds it to the port passed in, and sets */
/*      it to listen.                                                      */
/*    Causes MiM to DieWithError if any of the socket(), bind(), or        */
/*      listen() functions fail.                                           */
/*                                                                         */
/*    Parameters:                                                          */
/*          port -- selected listening port                                */
/*    Returns:                                                             */
/*          the listening socket that was created                          */
/***************************************************************************/
SOCKET CreateTCPListenSocket(unsigned short port)
{
    SOCKET sock;                    /* socket to create */
    struct sockaddr_in LocalAddr;   /* Local address */

    /* Create socket for incoming connections */
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");
      
    /* Construct local address structure */
    memset(&LocalAddr, 0, sizeof(LocalAddr));      /* Zero out structure */
    LocalAddr.sin_family = AF_INET;                /* Internet address family */
    LocalAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    LocalAddr.sin_port = htons(port);              /* Local port */

    /* Bind to the local address */
    if (bind(sock, (struct sockaddr *) &LocalAddr, sizeof(LocalAddr)) < 0)
        DieWithError("bind() failed");

    /* Mark the socket so it will listen for incoming connections */
    if (listen(sock, MAXPENDING) < 0)
        DieWithError("listen() failed");

    return sock;
}


/***************************************************************************/
/* AcceptTCPConnection                                                     */
/*    Accepts a connection from the client, reports to stdout the client's */
/*      address, and returns the connection's socket.                      */
/*                                                                         */
/*    Parameters:                                                          */
/*          servSock -- the listening socket                               */
/*    Returns:                                                             */
/*          The return value of accept(), a newly created socket           */
/*              connecting the client with MiM.                            */
/*                                                                         */
/*    CAVEAT:                                                              */
/*          accept() blocks.                                               */
/*          This means that MiM cannot respond while waiting for a client  */
/*              to connect.  The only other way to exit the program while  */
/*              it is at this point is to Ctrl-C it.                       */
/*          A desirable refinement would be to use a select() loop to test */
/*              for an incoming connection as well as for the user's       */
/*              pressing of the ESC key via the TestForQuit() function.    */
/***************************************************************************/
SOCKET AcceptTCPConnection(SOCKET servSock)
{
    SOCKET clntSock;                /* Socket handle for client */
    struct sockaddr_in ClntAddr;    /* Client address */
    int clntLen;          /* Length of client address data structure */

    /* Set the size of the in-out parameter */
    clntLen = sizeof(ClntAddr);
    
    /* Wait for a client to connect */
    if ( (clntSock = accept(servSock, 
                    (struct sockaddr *) &ClntAddr, &clntLen) ) < 0)
        DieWithError("accept() failed");
    
    /* clntSock is connected to a client! */
    
    printf("Handling client %s\n", inet_ntoa(ClntAddr.sin_addr));

    return clntSock;
}



/************************************************************/
/* UDP Session Handling Functions                           */
/************************************************************/

/************************************************************/
/* UDP Session Handling Function Prototypes                 */
/************************************************************/
SOCKET CreateUDPListeningSocket(unsigned short port);
void HandleUDPMsg(SOCKET in_sock,SOCKET out_sock,char *ID,
                  struct sockaddr_in *fromAddr, struct sockaddr_in *toAddr);

/***************************************************************************/
/* ProcessUDP                                                              */
/*    Processes the UDP session:                                           */
/*      Creates and initializes the server and client sockets.             */
/*      Loops until the user presses the ESC key:                          */
/*          Using select(), checks either socket for input                 */
/*          When a datagram is received, calls HandleUDPMsg which reads    */
/*              the datagram and sends it to the other socket as well as   */
/*              writing it to the capture file.                            */
/*                                                                         */
/*    Parameters:                                                          */
/*          ListenPort -- selected "listening" port                        */
/*          servIP -- the server's dotted-decimal IP address               */
/*          ServPort -- server's port                                      */
/*    Returns:                                                             */
/*          void                                                           */
/***************************************************************************/
void ProcessUDP(unsigned short ListenPort,char *servIP,unsigned short ServPort)
{
    SOCKET servSock;                /* Socket handle for talking to server */
    SOCKET clntSock;                /* Socket handle for talking to client */
    struct sockaddr_in ServAddr;    /* Server address */
    struct sockaddr_in ClntAddr;    /* Client address */

    fd_set sockSet;                 /* Set of socket handles for select() */
    long timeout;                   /* Timeout seconds value */
    long timeout_ms;                /* Timeout microseconds  */
    struct timeval selTimeout;      /* Timeout for select()  */

    printf("Processing UDP Session\n");

    /* create "listening" socket to receive client datagrams */
    clntSock = CreateUDPListeningSocket(ListenPort);

    /* Create UDP socket for communicating with the server */
    if ((servSock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
        DieWithError("socket() failed");

    /* Construct the server address structure */
    memset(&ClntAddr, 0, sizeof(ClntAddr));     /* Zero out structure */
    memset(&ServAddr, 0, sizeof(ServAddr));     /* Zero out structure */
    ServAddr.sin_family      = AF_INET;         /* Internet address family */
    ServAddr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
    ServAddr.sin_port        = htons(ServPort);     /* Server port */

    /* initialize the timeout value for select()  */
    /* will use these each time through the loop  */
    timeout = 0L;
    timeout_ms = 1000L;

    /* loop until user presses the ESC key       */
    while (TestForQuit() == FALSE)
    {
        /* Zero socket handle vector and set for server sockets */
        /* This must be reset every time select() is called */
        FD_ZERO(&sockSet);
        FD_SET(servSock, &sockSet);
        FD_SET(clntSock, &sockSet);

        /* Timeout specification */
        /* This must be reset every time select() is called */
        selTimeout.tv_sec = timeout;       /* timeout (secs.) */
        selTimeout.tv_usec = timeout_ms;   /* microseconds */

        /* Suspend program until handle is ready or timeout */
        /* The first parameter to select() is ignored in Winsock */
        /* We are only interested in sockets ready to be read    */
        if (select(0, &sockSet, NULL, NULL, NULL) > 0)
        {
            if (FD_ISSET(servSock, &sockSet))
            {
                /* handle datagram received from the server */
                HandleUDPMsg(servSock,clntSock,"Server",&ServAddr,&ClntAddr);
            }

            if (FD_ISSET(clntSock, &sockSet))
            {
                /* handle datagram received from the client */
                HandleUDPMsg(clntSock,servSock,"Client",&ClntAddr,&ServAddr);
            }
        }

    }

    /* shutdown */
    /* should reach here since UDP has no "graceful shutdown" issues */
    closesocket(servSock);
    closesocket(clntSock);
}



/***************************************************************************/
/* HandleUDPMsg                                                            */
/*    Reads the data packet from the incoming socket and relays it out to  */
/*      the outgoing socket.                                               */
/*    Also writes the data to the capture file.                            */
/*                                                                         */
/*    Parameters:                                                          */
/*          in_sock -- the socket to read the data from                    */
/*          out_sock -- the socket to write the data out to                */
/*          ID -- string identifying the source of the data                */
/*    Returns:                                                             */
/*          void                                                           */
/***************************************************************************/
void HandleUDPMsg(SOCKET in_sock,SOCKET out_sock,char *ID,
                  struct sockaddr_in *fromAddr, struct sockaddr_in *toAddr)
{
    char title[40];
    char buffer[UDPRCVBUFSIZE];     /* Buffer for datagram */
    int bytesRcvd;                  /* Bytes read in recvfrom() */
    char sErrorMsg[100];
    struct sockaddr_in ClntAddr;
    int   cliLen;
     
    cliLen = sizeof(ClntAddr);

    /* Receive up to the buffer size bytes from the sender */
    if ((bytesRcvd = recvfrom(in_sock, buffer, UDPRCVBUFSIZE, 0,
            (struct sockaddr *) &ClntAddr, &cliLen)) <= 0)
        DieWithError("recvfrom() failed");
    
    /* Set up label for source of the packet */
    sprintf(title,"%s [%s:%d]:",ID,inet_ntoa(ClntAddr.sin_addr),ntohs(ClntAddr.sin_port));

    /* write the source label and packet data to the capture file */
    CaptureData(title,buffer,bytesRcvd);

    /* if came from client, then update address */
    if (!strcmp(ID,"Client"))
    {
        memcpy(fromAddr, &ClntAddr, cliLen);
    }

    /* echo message out the other port  */
    if (sendto(out_sock, buffer, bytesRcvd, 0, (struct sockaddr *) toAddr, 
                     sizeof(*toAddr)) != bytesRcvd)
    {
        sprintf(sErrorMsg,"%s send() sent a different number of bytes "
                            "than expected",ID);
        DieWithError(sErrorMsg);
    }
}


/***************************************************************************/
/* CreateUDPListeningSocket                                                */
/*    Creates a UDP socket and binds it to the port passed in, effectively */
/*      setting it to "listen".                                            */
/*    Although UDP doesn't use listen(), the purpose of this socket is for */
/*      it to "listen" for client datagrams.  This socket will also serve  */
/*      as the client socket.                                              */
/*    Causes MiM to DieWithError if any of the socket() or bind()          */
/*      functions fail.                                                    */
/*                                                                         */
/*    Parameters:                                                          */
/*          port -- selected "listening" port                              */
/*    Returns:                                                             */
/*          the "listening" socket that was created                        */
/***************************************************************************/
SOCKET CreateUDPListeningSocket(unsigned short port)
{
    SOCKET sock;                    /* socket to create */
    struct sockaddr_in LocalAddr;   /* Local address */

    /* Create socket for incoming datagrams */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        DieWithError("server socket() failed");
      
    /* Construct local address structure */
    memset(&LocalAddr, 0, sizeof(LocalAddr));   /* Zero out structure */
    LocalAddr.sin_family = AF_INET;             /* Internet address family */
    LocalAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    LocalAddr.sin_port = htons(port);              /* Local port */

    /* Bind to the local address */
    if (bind(sock, (struct sockaddr *) &LocalAddr, sizeof(LocalAddr)) < 0)
        DieWithError("bind() failed");

    return sock;
}







/************************************************************/
/* Capture File Functions                                   */
/************************************************************/

/*************************************************************/
/* capture file pointer                                      */
/*   global variable used only by the Capture File functions */
/*************************************************************/
FILE *fp = NULL;

/***************************************************************************/
/* OpenCaptureFile                                                         */
/*    Opens a text file to which the packet data will be saved.            */
/*          If no filename has been given, as the calling function         */
/*          indicates by passing in NULL, then the packet data will go to  */
/*          the console via stdout.                                        */
/*                                                                         */
/*    Parameters:                                                          */
/*          filename -- name of the capture file to be created.            */
/*    Returns:                                                             */
/*          BOOL --                                                        */
/*              TRUE == successfully opened capture file.                  */
/*              FALSE == failed to open capture file.                      */
/*                                                                         */
/*  CAVEAT:                                                                */
/*      The file is opened for output, NOT append.                         */
/*      That means that if a file by that name already exists, then it     */
/*          will be deleted and replaced by this new file.                 */
/***************************************************************************/
BOOL OpenCaptureFile(char *filename)
{
    if (filename == NULL)
    {
        printf("CaptureFile: send to stdout\n");
        fp = stdout;
        return TRUE;
    }
    else
    {
        printf("CaptureFile: filename = %s\n",filename);
        if ((fp=fopen(filename,"wt")) == NULL)
            return FALSE;
        else
            return TRUE;
    }
}


/***************************************************************************/
/* CloseCaptureFile                                                        */
/*    Closes the capture file.  If no capture file had been designated     */
/*          (ie, if fp == stdout), then no action is taken.                */
/*                                                                         */
/*    Parameters:                                                          */
/*          None                                                           */
/*    Returns:                                                             */
/*          void                                                           */
/***************************************************************************/
void CloseCaptureFile(void)
{
    if ( (fp != NULL) && (fp != stdout) )
        fclose(fp);
    fp = NULL;
}


/***************************************************************************/
/* CaptureData                                                             */
/*    Closes the capture file.  If no capture file had been designated     */
/*          (ie, if fp == stdout), then no action is taken.                */
/*                                                                         */
/*    Parameters:                                                          */
/*          title -- string identifying whether the data came from the     */
/*              server or from the client.                                 */
/*              This will be used to label the data in the capture file.   */
/*          buffer -- the packet data to be captured.  It will be text     */
/*              with embedded binary data (eg, telnet command codes).      */
/*          count -- number of characters of packet data.                  */
/*    Returns:                                                             */
/*          void                                                           */
/*                                                                         */
/*  File Format:                                                           */
/*              <source>:<CR><LF>                                          */
/*              <data string><CR><LF>                                      */
/*              [<data string><CR><LF>]                                    */
/*      where:                                                             */
/*          <source> is an identifying string, such as  "Server" or        */
/*                  "Client" as given in the title parameter.              */
/*          <data string> is the packet data, written exactly as it        */
/*                  was received.                                          */
/*                  This means that unprintable characters are stored as   */
/*                  their unprintable character code; ie, the string may   */
/*                  very well contain binary data.                         */
/*          <CR><LF> is the character sequence "carriage return/line feed" */
/*                  which is what "\n" generates in DOS/Windows.           */
/*                  This is appended in addition to the <data string>.     */
/*          [<data string><CR><LF>] means that any number of these lines   */
/*                  may be present.                                        */
/*                                                                         */
/*  Reading a Capture File:                                                */
/*      Because unprintable binary data will very likely be embedded in    */
/*      the file's text, conventional means of viewing a text file will    */
/*      not work well.  Besides, that would defeat the original purpose of */
/*      MiM, which was to capture the binary telnet command codes in order */
/*      to observe actual client-server setup negotiation.                 */
/*      Consider using any program that would generate a hex dump, such    */
/*      as I discuss on my page, "Generating a Hex Dump", at               */
/*      http://members.aol.com/DSC30574/misc/hexdump.html                  */
/*      In my experiment, I wrote a quick-and-dirty program, MUNG, which   */
/*      displays unprintable characters as their character code value.     */
/***************************************************************************/
void CaptureData(char *title,char *buffer,int count)
{
    int  i;
    char ch;

    fprintf(fp,"%s\n",title);
    for (i=0; i<count; i++)
    {
        ch = buffer[i];
        fprintf(fp,"%c",ch);
    }
    fprintf(fp,"\n"); 
    fflush(fp);
}



/************************************************************/
/* Sockets Support Functions                                */
/************************************************************/

/***************************************************************************/
/* IsAddress                                                               */
/*    Tests whether a string contains a valid IP address.                  */
/*                                                                         */
/*    Parameters:                                                          */
/*          s -- string containing a dotted-decimal address                */
/*    Returns:                                                             */
/*          TRUE -- string contains a valid address                        */
/*          FALSE -- string does not                                       */
/*                                                                         */
/*  CAVEAT:                                                                */
/*      The test is performed by calling inet_addr.                        */
/*          This function is being replaced; refer to the function's man   */
/*          pages either on your system or via Google.                     */
/*      The INADDR_NONE failure value is defined on my system as           */
/*          0xFFFFFFFF, which is also the -1 failure value in UNIX         */
/*          documentation.  It is also a valid value for the common        */
/*          broadcast address of 255.255.255.255, and so the IsAddress     */
/*          function will give a false failure for that one address.       */
/***************************************************************************/
BOOL IsAddress(char *s)
{
    return (inet_addr(s) == INADDR_NONE) ? FALSE : TRUE;
}


/***************************************************************************/
/* ResolveHostAddress                                                      */
/*    Given a host name or IP address, resolve it so that we end up with   */
/*          an IP address.                                                 */
/*                                                                         */
/*    Parameters:                                                          */
/*          addr -- pointer to a string buffer that will receive the       */
/*                  dotted-decimal IP address.                             */
/*          name -- string containing the input data.  Could be either a   */
/*                  host name or a dotted-decimal IP address.              */
/*    Returns:                                                             */
/*          char* to the IP address, addr, for possible use in a           */
/*                  function call.                                         */
/*          NULL if the look-up fails.                                     */
/*                                                                         */
/*    CAVEAT:                                                              */
/*          Calling function must allocate a char buffer for addr that     */
/*              will be big enough to receive a dotted-decimal IP address. */
/***************************************************************************/
char *ResolveHostAddress(char *addr,char *name)
{
    struct hostent *he;

    if (IsAddress(name) == TRUE)
    {
        strcpy(addr,name);
        return addr;
    }

    he = gethostbyname(name);
    if (he == NULL)
    {
        printf("gethostbyname for %s failed (%d)\n",name,WSAGetLastError());
        return NULL;
    }

    if (he->h_addr_list == NULL)
    {
        printf("No h_addr_list present for %s.\n",name);
        return NULL;
    }

    strcpy(addr,inet_ntoa(*((struct in_addr*)he->h_addr)));
    return addr;
}


/***************************************************************************/
/* ResolveService                                                          */
/*    Given a service name or port number, resolve it so that we end up    */
/*          with a port number.                                            */
/*                                                                         */
/*    Parameters:                                                          */
/*          service -- string containing the input data, which could be    */
/*                  either the port number or the service name.            */
/*          protocol -- string containing the protocol, tcp or udp.        */
/*                  Needed in the library calls.                           */
/*    Returns:                                                             */
/*          port number.  0 if resolution failed.                          */
/***************************************************************************/
unsigned short ResolveService(char *service, char *protocol)
{
    struct servent *serv;    /* Structure containing service information */
    unsigned short port;     /* Port to return */

    if ((port = atoi(service)) == 0)  /* Is port numeric?  */
    {
        /* Not numeric.  Try to find as name */
        if ((serv = getservbyname(service, protocol)) == NULL)
        {
            /* Port not found by name */
            printf("getservbyname for %s failed (%d)\n",service,
                        WSAGetLastError());
            return 0;
        }
        else
            /* Found port (network byte order) by name */
            port = ntohs(serv->s_port); 
    }

/*   else port is numeric; value already set in if-statement  */

    return port;
}


/***************************************************************************/
/* GetErrorCode                                                            */
/*    Associates a Winsock error code with its error name and descriptive  */
/*          text.                                                          */
/*                                                                         */
/*    Returns boolean value:                                               */
/*      TRUE -- error code found.  Associated name and descriptive text    */
/*              are copied to the sErrorName and sErrorDesc parameters.    */
/*      FALSE -- error code not found.  sErrorName and sErrorDesc set      */
/*              to empty strings.                                          */
/***************************************************************************/
struct WS_ErrorCodes
{
    int  iErrorCode;
    char sName[24];
    char sDesc[54];
};

struct WS_ErrorCodes error_codes[] =
    {
        {10004,"WSAEINTR",          "Interrupted function call."}, 
        {10013,"WSAEACCES",         "Permission denied."},
        {10014,"WSAEFAULT",         "Bad address."}, 
        {10022,"WSAEINVAL",         "Invalid argument."}, 
        {10024,"WSAEMFILE",         "Too many open files."}, 
        {10035,"WSAEWOULDBLOCK",    "Resource temporarily unavailable."}, 
        {10036,"WSAEINPROGRESS",    "Operation now in progress."}, 
        {10037,"WSAEALREADY",       "Operation already in progress."}, 
        {10038,"WSAENOTSOCK",       "Socket operation on non-socket."}, 
        {10039,"WSAEDESTADDRREQ",   "Destination address required."}, 
        {10040,"WSAEMSGSIZE",       "Message too long."}, 
        {10041,"WSAEPROTOTYPE",     "Protocol wrong type for socket."}, 
        {10042,"WSAENOPROTOOPT",    "Bad protocol option."}, 
        {10043,"WSAEPROTONOSUPPORT","Protocol not supported."}, 
        {10044,"WSAESOCKTNOSUPPORT","Socket type not supported."}, 
        {10045,"WSAEOPNOTSUPP",     "Operation not supported."}, 
        {10046,"WSAEPFNOSUPPORT",   "Protocol family not supported."}, 
        {10047,"WSAEAFNOSUPPORT",   "Address family not supported by protocol family."}, 
        {10048,"WSAEADDRINUSE",     "Address already in use."},
        {10049,"WSAEADDRNOTAVAIL",  "Cannot assign requested address."},
        {10050,"WSAENETDOWN",       "Network is down."}, 
        {10051,"WSAENETUNREACH",    "Network is unreachable."}, 
        {10052,"WSAENETRESET",      "Network dropped connection on reset."}, 
        {10053,"WSAECONNABORTED",   "Software caused connection abort."}, 
        {10054,"WSAECONNRESET",     "Connection reset by peer."}, 
        {10055,"WSAENOBUFS",        "No buffer space available."}, 
        {10056,"WSAEISCONN",        "Socket is already connected."}, 
        {10057,"WSAENOTCONN",       "Socket is not connected."}, 
        {10058,"WSAESHUTDOWN",      "Cannot send after socket shutdown."}, 
        {10060,"WSAETIMEDOUT",      "Connection timed out."}, 
        {10061,"WSAECONNREFUSED",   "Connection refused."}, 
        {10064,"WSAEHOSTDOWN",      "Host is down."}, 
        {10065,"WSAEHOSTUNREACH",   "No route to host."}, 
        {10067,"WSAEPROCLIM",       "Too many processes."}, 
        {10091,"WSASYSNOTREADY",    "Network subsystem is unavailable."}, 
        {10092,"WSAVERNOTSUPPORTED","WINSOCK.DLL version out of range."}, 
        {10093,"WSANOTINITIALISED", "Successful WSAStartup not yet performed."}, 
        {10094,"WSAEDISCON",        "Graceful shutdown in progress."}, 
        {10109,"WSATYPE_NOT_FOUND", "Class type not found."}, 
        {11001,"WSAHOST_NOT_FOUND", "Host not found."}, 
        {11002,"WSATRY_AGAIN",      "Non-authoritative host not found."}, 
        {11003,"WSANO_RECOVERY",    "This is a non-recoverable error."}, 
        {11004,"WSANO_DATA",        "Valid name, no data record of requested type."}, 
        {0,"",""} 
    };

BOOL GetErrorCode(int err,char *sErrorName,char *sErrorDesc)
{
    int i;

    /* search loop; this for-loop intentionally has no body */
    for (i=0; 
         error_codes[i].iErrorCode != err && error_codes[i].iErrorCode != 0; 
         i++);

    if (error_codes[i].iErrorCode == 0) // not found
    {
        strcpy(sErrorName,"");
        strcpy(sErrorDesc,"");
        return FALSE;
    }
    else
    {
        strcpy(sErrorName,error_codes[i].sName);
        strcpy(sErrorDesc,error_codes[i].sDesc);
        return TRUE;
    }
}


/***************************************************************************/
/* DieWithError                                                            */
/*    Separate function for handling errors                                */
/*    Reports an error, closes the capture file, and then terminates       */
/*        the program                                                      */
/***************************************************************************/
void DieWithError(char *errorMessage)
{
    char sErrorName[30];
    char sErrorDesc[60];

    int err = WSAGetLastError();

    /* if error code found */
    if (GetErrorCode(err,sErrorName,sErrorDesc) == TRUE) 
    {
        fprintf(stderr,"%s: %s,%s\n", errorMessage,sErrorName,sErrorDesc);
    }
    else  /* error code not found */
    {
        fprintf(stderr,"%s: %d\n", errorMessage,err);
    }

    CloseCaptureFile();
    exit(1);
}


/**************************************************************/
/*  Support Functions                                         */
/**************************************************************/

/***************************************************************************/
/* GetCommandLineParameters                                                */
/*    Parses the argv list to extract the arguments and options.           */
/*    If any errors are found, return to main with FALSE.                  */
/*                                                                         */
/*    Parameters:                                                          */
/*          argc -- number of command line arguments, as passed to main(). */
/*          argv -- array of strings containing the command line           */
/*                  arguments, as passed to main().                        */
/*          *params -- pointer to a Parameters struct.  This function will */
/*                  fill that struct according to the options and          */
/*                  arguments found in argv:                               */
/*          typedef struct                                                 */
/*          {                                                              */
/*              BOOL bTCP;      -- TRUE == run TCP (default, -t)           */
/*                              -- FALSE == run UDP (-u)                   */
/*              BOOL bCapture;  -- capture file provided (-f)              */
/*              char *sCaptureFile;  -- capture file name                  */
/*              char *sListenPort;   -- listen port string                 */
/*              char *sServer;       -- server string                      */
/*              char *sServerPort;   -- server port string                 */
/*          } Parameters;                                                  */
/*  Returns:                                                               */
/*      TRUE -- no errors found                                            */
/*      FALSE -- error found                                               */
/*                                                                         */
/*  To simplify this portion of the code, MiM expects all options to       */
/*  precede the arguments.  It also expects all options to be separate     */
/*  (ie, "-u -f" instead of "-uf") and it expects there to be a space      */
/*  between the -f and the capture file name.                              */
/*                                                                         */
/*  The command-line syntax is (on one line):                              */
/*      MiM  [-u] [-t] [-f <capture file>] <listen-port>                   */
/*              <server addr> [<server port>]                              */
/*    Arguments:                                                           */
/*      <listen-port> -- is the port that the client will connect to MiM   */
/*              with.  It may be either a number or a well-known service   */
/*              name.                                                      */
/*              This argument is required.                                 */
/*      <server addr> -- is the address of the server that MiM will        */
/*              connect with.  It may be either a host name or a           */
/*              dotted-decimal IP address.                                 */
/*              This argument is required.                                 */
/*      <server port> -- is the port on the server that MiM will connect   */
/*              to.  It may be either a number or a well-known service     */
/*              name.                                                      */
/*              This argument is optional.  If it is not given, the        */
/*              default value will be the telnet port, 23.                 */
/*    Options:                                                             */
/*      -u  -- tells MiM to run a UDP session.                             */
/*      -t  -- tells MiM to run a TCP session.  This is the default mode,  */
/*              so it is not necessary to specify this option.             */
/*      -f  -- specifies the name of the capture file.                     */
/*              If this option is used, then the file name is required;    */
/*                  failure to provide the file name will result in an     */
/*                  error.                                                 */
/*              If this option is not used, then by default the output     */
/*                  will be routed to the console via the standard output  */
/*                  file, stdout.                                          */
/***************************************************************************/
BOOL GetCommandLineParameters(int argc, char *argv[], Parameters  *params)
{
    int  iParams = 0;
    int  i;

    if (argc <= 1)
        return FALSE;

    for (i=1; i<argc; i++)
    {
        if (argv[i][0] == '-')
        {
            switch (argv[i][1])
            {
                case 'h':
                    DisplayManPage();
                    exit(0);
                case 'f':
                    params->bCapture = TRUE;
                    i++; // skip to required capture file name
                    if (i >= argc)
                        return FALSE;
                    else if (argv[i][0] == '-')
                        return FALSE;
                    else
                    {
                        params->sCaptureFile = (char *)malloc(strlen(argv[i])+1);
                        strcpy(params->sCaptureFile,argv[i]);
                    }                            
                    break;
                case 't':
                    params->bTCP = TRUE;
                    break;
                case 'u':
                    params->bTCP = FALSE;
                    break;
                default:
                    return FALSE;
            }                                                
        }
        /* else it's an argument */            
        else
        {
            switch(iParams)
            {
                case 0:
                    params->sListenPort = (char *)malloc(strlen(argv[i])+1);
                    strcpy(params->sListenPort,argv[i]);
                    iParams++;
                    break;
                case 1:
                    params->sServer = (char *)malloc(strlen(argv[i])+1);
                    strcpy(params->sServer,argv[i]);
                    iParams++;
                    break;
                case 2:
                    params->sServerPort = (char *)malloc(strlen(argv[i])+1);
                    strcpy(params->sServerPort,argv[i]);
                    iParams++;
                    break;
                default:
                    return FALSE;
            }
        }
    }

    if ( (iParams < 2) || (iParams > 3) )
        return FALSE;
    else 
        return TRUE;
}


/***************************************************************************/
/* ProcessCmdLineParameters                                                */
/*    Resolves the port numbers and the server address, sets the TCP/UDP   */
/*    flag, and opens the capture file.                                    */
/*    If any errors are found, return to main with FALSE.                  */
/*                                                                         */
/*    Parameters:                                                          */
/*          *params -- pointer to a Parameters struct, which was filled by */
/*                  GetCommandLineParameters.                              */
/*          *bTCP -- TCP/UDP flag                                          */
/*          *servIP -- server IP as a dotted-decimal string                */ 
/*          *ServPort -- resolved server port number                       */ 
/*          ListenPort -- resolved listen port number the options and      */
/*                  and arguments found in argv:                           */
/*          typedef struct                                                 */
/*          {                                                              */
/*              BOOL bTCP;      -- TRUE == run TCP (default, -t)           */
/*                              -- FALSE == run UDP (-u)                   */
/*              BOOL bCapture;  -- capture file provided (-f)              */
/*              char *sCaptureFile;  -- capture file name                  */
/*              char *sListenPort;   -- listen port string                 */
/*              char *sServer;       -- server string                      */
/*              char *sServerPort;   -- server port string                 */
/*          } Parameters;                                                  */
/*  Returns:                                                               */
/*      TRUE -- no errors found                                            */
/*      FALSE -- error found                                               */
/***************************************************************************/
BOOL ProcessCmdLineParameters(Parameters  *params, 
                              BOOL *bTCP, char *servIP, 
                              unsigned short *ServPort, 
                              unsigned short *ListenPort)
{
    *bTCP = params->bTCP;

    //    ListenPort = atoi(params[1]);             /* second arg: listen port */
    if (*bTCP == TRUE)
        /* second arg: listen port */
        *ListenPort = ResolveService(params->sListenPort,"tcp");
    else
        /* second arg: listen port */
        *ListenPort = ResolveService(params->sListenPort,"udp"); 

    if (*ListenPort == 0)
        return FALSE;

    /* third arg: server IP address (dotted quad) */

    if (IsAddress(params->sServer) == TRUE)
    {
        strcpy(servIP,params->sServer);
        printf("IP = %s\n",servIP);
    }
    else
    {
        /* third arg: server IP address (dotted quad) */
        if (ResolveHostAddress(servIP,params->sServer) == NULL)          
            return FALSE;
        else
            printf("%s IP = %s\n",params->sServer,servIP);
    }

    if (params->sServerPort != NULL)
    {
        if (*bTCP == TRUE)
            /* Use given port, if any */
            *ServPort = ResolveService(params->sServerPort,"tcp");  // atoi(params[3]); 
        else
            /* Use given port, if any */
            *ServPort = ResolveService(params->sServerPort,"udp");  // atoi(params[3]); 
        if (*ServPort == 0)
            return FALSE;
    }
    else
        *ServPort = TELNETPORT;    /* otherwise, use the well-known port */

    if (params->bCapture == TRUE)
    {
        if (OpenCaptureFile(params->sCaptureFile) == FALSE)
            printf("Capture File Open failed\n");
    }
    else
        OpenCaptureFile(NULL);

    printf("Peer IP = %s\n",servIP);
    printf("Peer Port = %d\n",*ServPort);
    printf("Listen Port = %d\n",*ListenPort);
    
    return TRUE;
}


/***************************************************************************/
/* DisplayManPage                                                          */
/*    In response to the help option (-h), displays the ManPage string     */
/*        array which describes the program and how to use it.             */
/***************************************************************************/
const char ManPage[][75] = 
    {
        "  \"Man-in-Middle\" connects a client to a server and \n",
        "      dumps all data packets to a capture file.\n",
        "  Accepts either IP address or domain name of server.\n",
        "  Accepts either port number or service name (ie, telnet).\n",
        "To use:\n",
        "  1. Run MiM.\n",
        "  2. Connect client to MiM and run session.\n",
        "  3. Examine capture file.  It may contain binary data.\n",
        "Parameters:\n",
        "   <listen-port> -- port through which client will connect to MiM.\n",
        "                     Required.\n",
        "   <server> -- address of server MiM will connect to.\n",
        "                     Required.\n",
        "   <server port> -- port on the server MiM will connect to.\n",
        "                     Optional; defaults to telnet (port 23).\n",
        "Options:\n",
        "   -h  help -- this screen.\n",
        "   -u  run UDP session.\n",
        "   -t  run TCP session (default).\n",
        "   -f  name capture file; must be followed by file name.\n",
        "         (if not used, output defaults to stdout)\n",
        ""
    };

void DisplayManPage(void)
{
    int i;

    fprintf(stdout,"Usage: %s\n",sUsage);
    for (i=0; ManPage[i][0] != '\0'; i++)
        fprintf(stdout,ManPage[i]);
}


/***************************************************************************/
/* TestForQuit                                                             */
/*    Tests for the ESC key (ASCII code 27) having been pressed.           */
/*    Returns TRUE if the ESC key has been pressed                         */
/*          FALSE if a different key or no key has been pressed.           */
/*                                                                         */
/*    Uses the conio library, because reading the keyboard normally blocks */
/*           -- ie, all processing stops until user has typed in a         */
/*          complete line and pressed ENTER.                               */
/*    conio's _kbhit() function allows the program to test whether a key   */
/*          has been pressed before it attempts to read it.  This prevents */
/*          blocking.                                                      */
/*    conio is not supported by UNIX/Linux, so to port this program to     */
/*          UNIX/Linux you will need to:                                   */
/*      1. This function need to be removed, or                            */
/*      2. A Linux port of conio would need to be used, or                 */
/*      3. This code would need to be replaced by functionally equivalent  */
/*              terminal-handling code.                                    */
/***************************************************************************/
BOOL TestForQuit(void)
{
    /* if "keyboard hit"; ie, a key has been pressed */
    if (_kbhit())
    {
        if (_getch() == '\x1B')  /* ESC */
            return TRUE;
        else
            return FALSE;
    }
    /* else allow program to continue on uninterrupted */
    else
        return FALSE;
}


/***************************/
/*   *****   END   *****   */
/***************************/
