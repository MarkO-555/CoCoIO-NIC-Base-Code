SIMPLE ECHO SERVER/CLIENT EXAMPLES FOR TCP AND UDP

David C. Wise, 2004                                                   
Email: dwise1@aol.com                                                 

***********************************************************************

These programs are intended for training purposes only.  
They are not nor were they ever intended for commercial or production use.
I disclaim any and all responsibility should you decide to use them.    

***********************************************************************

Source code in C and Windows binaries of simple client and server 
    applications for both the TCP and the UDP protocols.

Usage instructions listed in the source code header and available 
    by simply running the program with no arguments.
    
NOTES:  
    These programs implement the echo service as specified in RFC 862.

    These programs do not do DNS; all host addresses must be in 
        dotted-decimal format (eg, 192.168.0.1, 127.0.0.1).

    Entering the server port is optional.  If not included, it will
        default to the standard echo service port, 7.

    For security reasons, some systems may required you to have special 
        privileges to run the server program, such as being logged on
        as Administrator or root.  The simple alternative would be to
        specify a port number greater than 1024, for which you do not 
        need special privileges.

    Spaces in the program's command-line invocation separate arguments.
        In the UDP client, one of those parameters is the echo message 
        itself.  If the echo message consists of more than word, then 
        enclose it in quotation marks.

***********************************************************************

ZIP File Contents:
    ReadMe.txt
    mach.bat
    tcp_client.c
    tcp_server.c
    udp_client.c
    udp_server.c
    tcp_client.exe
    tcp_server.exe
    udp_client.exe
    udp_server.exe

***********************************************************************

Based on and modified from code examples from 
  "The Pocket Guide to TCP/IP Sockets: C Version"                  
  by Michael J. Donahoo and Kenneth L. Calvert:         
                                                                       
The original UNIX source code is freely available from their web site 
    at http://cs.baylor.edu/~donahoo/PocketSocket/textcode.html      
    and the Winsock version of the code at                           
    http://cs.baylor.edu/~donahoo/PocketSocket/winsock.html      
                                                                       
Please read the authors' disclaimer on their web site at              
    http://cs.ecs.baylor.edu/~donahoo/practical/CSockets/textcode.html 
In particular note that "the authors and the Publisher DISCLAIM ALL  
    EXPRESS AND IMPLIED WARRANTIES, including warranties of          
    merchantability and fitness for any particular purpose.          
Your use or reliance upon any sample code or other information in     
    [their] book will be at your own risk.                           
No one should use any sample code (or illustrations) from [their]     
    book in any software application without first obtaining         
    competent legal advice."                                         
                                                                       
***********************************************************************

These programs will compile under Windows or UNIX/Linux depending on    
    the setting of the WINSOCK_EXAMPLE define                        
The Winsock version will require the Winsock library to be linked in  
    (exact method and library name are compiler-dependent).
The Linux version does not require any special libraries;
    eg, gcc -o tcp_server tcp_server.c                
    
The batch file MACH.BAT has been included for building the programs 
    under Windows (in a "DOS" console) using a gcc port for Windows,
    such as MinGW.
    
I have included binaries of the programs compiled for Windows.

Usage instructions listed in the source code header and also available by 
    running the program without parameters.

***********************************************************************
End of File
***********************************************************************
